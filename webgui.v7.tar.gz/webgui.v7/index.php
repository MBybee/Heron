<?php if (substr_count($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip')) ob_start('ob_gzhandler'); else ob_start(); ?>
<!DOCTYPE html>
<html lang='en'>
 <head>
  <meta http-equiv='content-type' content='text/html; charset=UTF-8' />
  <meta name="viewport" content="width=100%, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no" />
  <!--
   This is part of the Heron Enterprise Management Suite for OpenEngine.Org
   This program is the web-based mid-tier for a server and db workflow management app
   Version 0.1
   All code and graphics © Copyright 2005-2013 Mike Bybee, OpenEngine.Org
   All rights reserved.
   This app is distributed under the BSD simplified license.
   You may obtain a copy of the License at:
   http://openengine.org/license.html 
   Included libraries may be under LGPL or MIT licenses.
   Libraries and Plugins Copyright their respective owners. See the libraries for their licenses. 
  -->
  <title>Alexandria</title>
  <link rel='shortcut icon' href='favicon.ico' type='image/x-icon' />
  <?php
   include_once 'js/scripts/jqFunc.php';
   insCSS();
   insScripts();
   insIE9pinning();
   /*Ἀλεξάνδρεια*/
  ?>
 </head>
 <body>
  <a href='#nav' class='navarea navpullout'><img src='images/bookmark-small.png' alt='menu' class='navhandle' title='Menu' /></a>
  <div class='navarea' id='nav' style='display:none'>
   <div class='navbutton'><img src='images/report.png' title='Reports' alt='Reports' class='navicon' id='reports' /></div>
   <div class='navbutton'><img src='images/db.png' title='DBs' alt='DBs' class='navicon' id='db' /></div>
   <div class='navbutton'><img src='images/host.png' title='Hosts' alt='Hosts' class='navicon' id='host' /></div>
   <div class='navbutton'><img src='images/tool.png' title='Apps' alt='Apps' class='navicon' id='tool' /></div>
   <div class='navbutton'><img src='images/pmo.png' title='PMO' alt='PMO' class='navicon' id='pmo' /></div>
  </div>
  <div class='header'>
   Alexandria
   <img src='images/search.png' alt='search' class='searchicon' id='searchicon' />
   <img src='images/rss.png' alt='news' class='rssicon' title='Show/Hide News' id='rssicon' />
  </div>
  <div class='search' id='searchbox'></div>
  <div class='rss' id='rssfeed'><div class='rss-fyi' id='newsevent1' title='News Event Detail'>News Event</div><div class='rss-warn' id='newsevent2' title='Warning Event Detail'>Warning Event</div><div class='rss-crit' id='newsevent33' title='Critical Event Detail'>Critical Event</div></div>
  <div class='content'>
    <div id='maintable'>
      <div class='row'>
      <span class='main-left'><img src='images/left.png' alt='Previous' class='left' title='Previous' id='main-left' /></span>     
      <div id='main-report'>
      <table class="footable main-table" id='main-table'>
      </table>
      </div>
      <span class='main-right'><img src='images/right.png' alt='Next' class='right' title='Next' id='main-right' /></span>
      </div> 
    </div>
    <div id='sub'>
      <div id='subtable'>
        <div class='row'>
        <span class='sub-left'><img src='images/left.png' alt='Previous' class='left' title='Previous' id='sub-left' /></span>
        <div id='sub-report'>
        <table class="footable sub-table" id='sub-table'>
        </table>
        </div>
        <span class='sub-right'><img src='images/right.png' alt='Next' class='right' title='Next' id='sub-right' /></span>
        </div> 
      </div>
    </div>
  </div>
  <div id='dialog-message' title='Message' class='dialog ui-dialog'>
    <div id='dialog-message-content' class='dialog-content ui-corner-all ui-helper-clearfix '></div>
  </div>
  <div id='dialog-form' title='Modify' class='dialog-form ui-dialog'>
    <div id='dialog-form-content' class='dialog-content ui-corner-all ui-helper-clearfix '></div>
  </div>
  <div id='dialog-small' title='Message' class='dialog-form ui-dialog'>
    <div id='dialog-small-content' class='dialog-content ui-corner-all ui-helper-clearfix '></div>
  </div>
  <div id='dialog-form-wizard-next' title='Host Wizard' class='dialog-form ui-dialog'>
    <div id='dialog-form-wizard-content-next' class='dialog-content ui-corner-all ui-helper-clearfix '></div>
  </div>
  <img id='add-button' src='images/plus.png' alt='Add' title='Add' class='secure' />
  <img id='remove-button' src='images/minus.png' alt='Remove' title='Remove' class='secure' />
  <img id='login-button' src='images/locked_icon.png' alt='Login' title='Click to Login' />
  <div class='license'><a href='http://openengine.org/license.html'>All code and graphics © Copyright 2005-2013 Mike Bybee.</a></div>
 </body>
</html>
