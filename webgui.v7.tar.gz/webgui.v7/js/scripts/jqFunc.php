<?php
 // This is part of the Heron Enterprise Management Suite for OpenEngine.Org
 // This program is the web-based mid-tier for a server and db workflow management app
 // Version 0.1
 // All code and graphics © Copyright 2005-2013 Mike Bybee, OpenEngine.Org
 // All rights reserved.
 // This app is distributed under the BSD simplified license.
 // You may obtain a copy of the License at:
 // http://openengine.org/license.html 
 // Included libraries may be under LGPL or MIT licenses.
 // Libraries and Plugins Copyright their respective owners. See the libraries for their licenses.
 
include_once 'classes.php';
include_once 'reports.php';

$dbtype = 'mysql';
$dbname = 'alex';
//$dbtype = 'sqlite';
//$dbname = 'heron.sqlite';
//$dbhost = '127.0.0.1';
$dbhost = 'alex.host'
$dbuser = 'alex';
$dbpass = 'yourpass';
$dbport = '3306';

// Added for AIX primarily
if(function_exists("date_default_timezone_set") and function_exists("date_default_timezone_get")){@date_default_timezone_set(@date_default_timezone_get()); }
$sqlQuery = new Query();
//print "<div class='hidden'>Version: 7." . $sqlQuery->execLit("select version()", 1, 1) . "</div>";

/*
 * Handle the jQuery function calls
 */
function insCSS($css = "js/css"){
    $style = "humanity";
    $uiver = "1.10.0";
    print( "  <link rel='stylesheet' type='text/css' href='$css/$style.$uiver/jquery-ui-$uiver.custom.min.css' />\n" );
    print( "  <link rel='stylesheet' type='text/css' href='$css/jqAlexandria.css' />\n" );
    
}

function insScripts($js = "js/scripts"){
    // Note - I need to make this parallel to speed up downloading scripts
    $uiver = "1.10.0";
    $ver   = "1.9.0";
    $pver  = "1.0.4";
    print( "  <script type='text/javascript' src='$js/jquery-$ver.min.js'></script>\n" );
    print( "  <script defer type='text/javascript' src='$js/jquery-ui-$uiver.custom.min.js'></script>\n" );
    print( "  <script defer type='text/javascript' src='$js/jquery.tablesorter.min.js'></script>\n" );
    print( "  <script defer type='text/javascript' src='$js/jquery.pageslide.min.js'></script>\n" );   
    print( "  <script defer type='text/javascript' src='$js/footable-0.1.js'></script>\n" );
    //print( "  <script defer type='text/javascript' src='$js/footable.sortable.js'></script>\n" );
    print( "  <script defer type='text/javascript' src='$js/jquery.flexbox.min.js'></script>\n" );
    print( "  <script defer type='text/javascript' src='$js/jqAlexandria.js'></script>\n" );
    
}

function insScriptsMin($js = "js/scripts"){
    $uiver = "1.10.0";
    $ver   = "1.9.0";
    print( "  <script type='text/javascript' src='$js/jquery-$ver.min.js'></script>\n" );
    print( "  <script async type='text/javascript' src='$js/jq-heron-light.js'></script>\n" );
    print( "  <script async type='text/javascript' src='$js/jquery.tablesorter.min.js'></script>\n" );
    print( "  <script defer type='text/javascript' src='$js/footable-0.1.js'></script>\n" );
}

function insIE9Pinning(){
    print( "  <meta name='msapplication-task' content='name=Alexandria 7; action-uri=http://openengine.org/heron/webgui.v7/; icon-uri=http://openengine.org/heron/webgui.v7/favicon.ico' />\n" );
    print( "  <meta name='msapplication-task' content='name=Reports; action-uri=http://openengine.org/heron/webgui.v7/; icon-uri=http://openengine.org/heron/webgui.v7/images/report.ico' />\n" );
    print( "  <meta name='msapplication-task' content='name=DBs; action-uri=http://openengine.org/heron/webgui.v7/index.php?jump=db; icon-uri=http://openengine.org/heron/webgui.v7/images/db.ico' />\n" );
    print( "  <meta name='msapplication-task' content='name=Hosts; action-uri=http://openengine.org/heron/webgui.v7/index.php?jump=host; icon-uri=http://openengine.org/heron/webgui.v7/images/host.ico' />\n" );
    print( "  <meta name='msapplication-task' content='name=Apps; action-uri=http://openengine.org/heron/webgui.v7/index.php?jump=app; icon-uri=http://openengine.org/heron/webgui.v7/images/tool.ico' />\n" );
    print( "  <meta name='msapplication-task' content='name=PMO; action-uri=http://openengine.org/heron/webgui.v7/index.php?jump=pmo; icon-uri=http://openengine.org/heron/webgui.v7/images/pmo.ico' />\n" );
    print("   <link rel='shortcut icon' href='http://openengine.org/heron/webgui.v7/favicon.ico' />\n");
    print("   <meta name='msapplication-starturl' content='http://openengine.org/heron/webgui.v7/' />\n");
    print("   <meta name='msapplication-window' content='width=1024; height=800' />\n");	
    print("   <meta name='msapplication-navbutton-color' content='#e2cfbe' />\n");
}

// Core Functions
function fixSQL($sql){
    // TODO this might be a bit too strong - it blocks / and \ to help block script attacks
    // if( preg_match('/^[\d\w.\s-:\@\[\]\(\)\+\-,]+$/', $sql) ){ return $sql; }
    // use if( preg_match('/^[\d\w.\/\s-:\\\@\[\]\(\)\+\-,]+$/', $sql) ){ return $sql; }  to allow embedding URLs
    // Handle common problems - this is not to make it fully safe, just to help
    
    if( is_array($sql) ){
        foreach( $sql as $field => &$val ){ 
            $val = str_replace(";", ":", $val);
            $val = str_replace("&", "and", $val);
            $val = str_replace("http", "link:", $val);
            $val = str_replace("href", "link:", $val); 
            $val = str_replace("mailto", "email", $val);
            $val = str_replace("'", "", $val);
            $val = str_replace("`", "", $val);
            $val = str_replace("\"", "", $val);
            $val = str_replace("--", "", $val);
            $val = str_replace("!", "", $val);
        }
        return $sql;
    }
    
    $sql = str_replace(";", ":", $sql);
    $sql = str_replace("&", "and", $sql);
    $sql = str_replace("http:", "link:", $sql);
    $sql = str_replace("href", "link:", $sql); 
    $sql = str_replace("mailto", "email", $sql);
    $sql = str_replace("'", "", $sql);
    $sql = str_replace("`", "", $sql);
    $sql = str_replace("\"", "", $sql);
    $sql = str_replace("--", "", $sql);
    $sql = str_replace("!", "", $sql);
    if( preg_match('/^[\d\w.\/\s-:\\\@\[\]\(\)\+\-,\"]+$/', $sql) ){ return $sql; }
    if( $sql == '%' ){ return $sql; }
    
    elseif( $sql == '' ){ return ''; }    
    else{ 
        print( "<p>String: $sql had invalid chars\n</p>" );
        return ''; 
    }
}

function insGenTable($query, $filter='%', $orderby='', $limit=0, $editable='y', $mincols='1' ){
    // Display a generic table with anything in it and an edit button     
    $sqlQuery = new Query();
    $filter  = fixSQL($filter);
    $results = $sqlQuery->exec($query, $filter, $orderby, $limit);
    
    print( "\t<table class='footable main-table' id='main-table'>\n" );
    print( "\t<caption class='table-caption'>$query</caption>\n" );
    print( "\t\t<thead>\n" );
    
    if( $sqlQuery->getCount() < 1 ){
        print( "<tr><th>No results found</th>\n</tr>\n</table>\n" );
	return;
    }
    else{
        // Insert the table headers
        $col = 0;
        foreach( $results[0] as $column => $val ){
            if( $col < $mincols ){ print( "<th> $column </th>" ); }
            elseif( ($col > 3) && ($col > $mincols) ){ print( "<th data-hide='phone,tablet'> $column </th>" ); }
            else{ print( "<th data-hide='phone'> $column </th>" ); }
            $col++;
        }      
        if( $editable == 'y' ){ print( "<th></th>\n" ); }
        print( "</tr>\n" );
	print( "\t\t</thead>\n" );
	print( "\t\t<tbody>\n" );
	
	for( $row = 0; $row < $sqlQuery->getCount(); $row++ ){
	    print( "\t\t<tr>");	    
            $editKey =-1;
            $tdnum   = 1;
	    foreach( $results[$row] as $key => $val ){
	        // Adding for the editing in place
	        if( $editKey < 0 ){ $editKey = $val; }
	        if( $tdnum == 1 ){ print( "<td class='expand'>$val</td>" );}
	        else{ print( "<td>$val</td>"); }
	        $tdnum++;
	    }
	    // Detail button
	    if( $editable == 'y' ){ print( "<td><button class='ui-widget edit editrow' alt='$editKey'><span id='editsubmit' class='ui-button-text ui-button-icon-primary ui-icon ui-icon-pencil editrow' alt='$editKey'>Details</span></button></td>" ); }
	    print( "\t\t</tr>\n" );
	}
		
	print( "\t\t</tbody>\n" );
        print( "\t</table>\n" );   
    }
}

function itemWizard($step, array $input){
    // This manages all the wizards: DB, Host, Network, eventually project and resource
    // I tried doing this fully modular, but that caused all kinds of extra weirdness. Going with a solution narrative.
    $now      = date('Y-m-d H:i:s');
    $mode     = isset($input['mode']) ? $input['mode'] : '';
    $sqlQuery = new Query();
    $input    = fixSQL($input);
    // Host wizard
    print( "<form id='update-form' class='update ui-widget' action='#' method='post'>\n" );
    
    switch ($step){
        case "eventstart":
            print( "<div>Adding new event not supported yet</div>\n");
        break;
        
        case "hoststart":
            print( "<div>Adding new manual Host</div>\n");
            $step = 'pickserver';  
            print( "<input type='hidden' name='step' value='$step' \>\n" );          
        break;
        
        case "dbstart":
            print( "<div>Adding new manual DB</div>\n");
            $step = 'pickhost';
            print( "<input type='hidden' name='step' value='$step' \>\n" );
        break;
        
        case "pickserver":
            // Pick a server to put a host on, or create a new one
	    $results = $sqlQuery->execLit("select skey, serial, servername from sys_key order by servername", 0);                
	    print( "<div>Choose existing server or type in new server name and serial</div>\n");
	    print( "<table id='update-table' class='ui-widget-content ui-widget-content ui-corner-all text update-table'>\n");
	    print( "<tr>\n  <td><label for='currserver'>Server: <td><td>" );
	    print( "<select id='currserver' name='currserver' class='ui-corner-all comboadd'>\n" );
            print( "<option name='currserver' value='new'> new </option> ");
            if( $sqlQuery->getCount() > 0 ){
	        for( $row = 0; $row < $sqlQuery->getCount(); $row++ ){ print "<option name='currserver' value='" . $results[$row]['servername'] . "' > " . $results[$row]['servername'] . " </option> ";	}
	    }
            print( "</select>");
	    print( "</td>\n </tr>\n" );
	    print( " <tr>\n  <td><label for='newserver'>New:<td><td><input type='text' name='newserver' value='' class='ui-corner-all' /></td>\n </tr>\n" );
	    $step = 'checkserver';
	    print( "<input type='hidden' name='step' value='$step' \>\n" );
        break;
        
        case "pickhost":
            // Pick a host to put a db on               
	    print( "<div>Choose host</div>\n");
	    print( "<table id='update-table' class='ui-widget-content ui-widget-content ui-corner-all text update-table'>\n");
	    print( "<tr>\n  <td><label for='host'>Host: <td><td>" );
	    print( "<select id='host' name='host' class='ui-corner-all comboadd'>\n" );
            //print( "<option name='new' value='new'> new </option> ");
            $results = $sqlQuery->execLit("select hostname from host_info where hostname not like '' group by hostname order by hostname", 0);
            if( $sqlQuery->getCount() > 0 ){
	        for( $row = 0; $row < $sqlQuery->getCount(); $row++ ){ print "<option name='host' value='" . $results[$row]['hostname'] . "' > " . $results[$row]['hostname'] . " </option> ";	}
	    }
            print( "</select>");
	    print( "</td>\n </tr>\n" );
	    $step = 'confirmhost';
	    print( "<input type='hidden' name='step' value='$step' \>\n" );
	    print( "<input type='hidden' name='confirm' value='1' \>\n" );
        break;
        
        case "checkserver":
            // Check that the server exists (in case they are trying to make a new one)
            // This also contains the small logic to create a new server if needed. Fairly long
            $confirm   = isset($input['confirm'])   ? $input['confirm']    : '';
            $newsrv    = isset($input['newserver']) ? $input['newserver']  : '';
            $currsrv   = isset($input['currserver'])? $input['currserver'] : '';
            $server    = isset($input['server'])    ? $input['server']     : '';
            $serial    = isset($input['serial'])    ? $input['serial']     : '';
            $serverip  = isset($input['serverip'])  ? $input['serverip']   : '';
            $dc        = isset($input['dc'])        ? $input['dc']         : '';
            $owner     = isset($input['owner'])     ? $input['owner']      : '';
            if($server == ''){
                if(($newsrv != '') && ($currsrv == 'new')){$server = $newsrv;}
                elseif(($currsrv == 'new') && ($newsrv != '')){$server = 'unknown';}
                else{ $server = $currsrv; }
            }
            
            $serverObj = new Server($server);
            $cssclass  = 'ui-corner-all';
            if(($serverObj->getKey() < 1) && ($confirm == '')){ 
                // This would be a new server, unconfirmed
                print( "<div>Create new system $server</div>\n");
	        print( "<div><table class='update-table'>\n");
	        print( "<tr><td>Name:</td><td><input type='text' name='server' class='$cssclass' value='$server' /></td></tr> ");
	        print( "<tr><td>Serial:</td><td><input type='text' name='serial' class='$cssclass' /></td></tr> ");
	        print( "<tr><td>IP Add:</td><td><input type='text' name='serverip' class='$cssclass'></td></tr>" );
	        print( "<tr><td>DC:</td><td>");
	        print( "<select name='dc' class='$cssclass comboadd'>\n" );
	        print( "<option name='dc' value=''></option> ");
	        $results = $sqlQuery->execLit("select datacenter from sys_info where datacenter not like '' group by datacenter order by datacenter", 0);
	        if( $sqlQuery->getCount() > 0 ){
	            for( $row = 0; $row < $sqlQuery->getCount(); $row++ ){ print "<option name='dc' value='" . $results[$row]['datacenter'] . "' > " . $results[$row]['datacenter'] . " </option> ";	 }
                }
	        print(" </select></td></tr>" );
	        print( "<tr><td>Owner:</td><td>" );
	        print( "<select name='owner' class='$cssclass comboadd'>\n" );
	        print( "<option name='owner' value=''></option> ");
	        $results = $sqlQuery->execLit( "select owner from host_info where owner not like '' group by owner order by owner", 0);
                if( $sqlQuery->getCount() > 0 ){
                    for( $row = 0; $row < $sqlQuery->getCount(); $row++ ){ print "<option name='owner' value='" . $results[$row]['owner'] . "' > " . $results[$row]['owner'] . " </option> "; }
	        }
	        print(" </select></td></tr>" );	        
	        print("</table>\n" );
	        print( "<input type='hidden' name='skey' value='0' \>\n" );
	        print( "<input type='hidden' name='confirm' value='0' \>\n" );
                $step = 'checkserver';
                print( "<input type='hidden' name='step' value='$step' \>\n" );
            }
            elseif(($serverObj->getKey() < 1) && ($confirm == '0')){
                // This would be a new server, prompting to confirm
                // Default IP if not provided
                $serverip = $serverip == '' ? '127.0.0.1' : $serverip;
                
	        $cssclass = 'ui-corner-all ui-state-disabled';              
	        print( "<div>Confirm new system $server</div>\n");
	        print( "<div><table class='update-table'>\n");
	        print( "<tr><td>Name:</td><td><input type='text' name='server' class='$cssclass' value='$server' readonly /></td></tr> ");
	        print( "<tr><td>Serial:</td><td><input type='text' name='serial' class='$cssclass' value='$serial' readonly /></td></tr> ");
	        print( "<tr><td>IP Add:</td><td><input type='text' name='serverip' class='$cssclass' value='$serverip' readonly /></td></tr>" );
	        print( "<tr><td>DC:</td><td><input type='text' name='dc' class='$cssclass' value='$dc' readonly /></td></tr>");
	        print( "<tr><td>Owner:</td><td><input type='text' name='owner' class='$cssclass' value='$owner' readonly /></td></tr>");
	        print("</table>\n");
	        print( "<input type='hidden' name='skey' value='0' \>\n" );
	        print( "<input type='hidden' name='confirm' value='1' \>\n" ); 
	        $step = 'checkserver';         
	        print( "<input type='hidden' name='step' value='$step' \>\n" );  
            }
            elseif(($serverObj->getKey() < 1) && ($confirm == '1')){
                // This is a new server, confirmed. Create the new server
                $skey = $serverObj->create($serverip, $serial, '', 'y', $owner, $dc);
                if( $skey < 1 ){ print( "Error creating server" ); }
                else{ print( "Server created" ); }
                print( "<input type='hidden' name='skey' value='$skey' \>\n" );
	        print( "<input type='hidden' name='confirm' value='1' \>\n" );
	        print( "<input type='hidden' name='server' value='$server' \>\n" );
                $step = 'confirmserver';
                print( "<input type='hidden' name='step' value='$step' \>\n" ); 
            }
            else{
                // Existing server, hop to confirm
                $step = 'confirmserver';
                print( "<input type='hidden' name='skey' value='" . $serverObj->getKey() . "' \>\n" );
	        print( "<input type='hidden' name='confirm' value='1' \>\n" );
	        print( "<input type='hidden' name='server' value='$server' \>\n" );
	        $input['confirm'] = 1;
                itemWizard($step, $input);
            }    
              
        break;
        
        case "createdb":
            // Create a new DB
            $confirm   = isset($input['confirm']) ? $input['confirm'] : '';
            $host      = isset($input['host'])    ? $input['host']    : '';
            $db        = isset($input['db'])      ? $input['db']      : '';
            $owner     = isset($input['owner'])   ? $input['owner']   : '';
            $rdbms     = isset($input['rdbms'])   ? $input['rdbms']   : '';
            $app       = isset($input['app'])     ? $input['app']     : '';
            $osuser    = isset($input['osuser'])  ? $input['osuser']  : '';
            $hkey      = isset($input['hkey'])    ? $input['hkey']    : '';
            $dkey      = isset($input['dkey'])    ? $input['dkey']    : '';
            $hostObj   = new Host($host);
            $dbObj     = new Database($db);
            $cssclass  = 'ui-corner-all';
            
            if( $hostObj->getKey() < 1 ){
                if( $hkey != '' ){
                    $host = $sqlQuery->execLit("select hostname from host_info where hkey = '$hkey'", 1, 1);
                    $hostObj = new Host($host);
                }
                else{
                    // No valid host was picked for this db
                    print( "<div>Unable to find host $host, please try again</div>" );
                    $step = 'pickhost'; 
                }            
            }
            
            if(($dbObj->getKey() < 1) && ($confirm == '') && ($hostObj->getKey() > 0)){ 
                // This would be a new db, unconfirmed
                print( "<div>Create new db on $host</div>\n");
	        print( "<div><table class='update-table'>\n");
	        print( "<tr><td>Name:</td><td><input type='text' name='db' id='db' class='$cssclass' value='' /></td></tr> ");
	        print( "<tr><td>RDBMS:</td><td>");
	        print( "<select name='rdbms' class='$cssclass comboadd'>\n" );
	        print( "<option name='rdbms' value=''></option> ");
	        print( "<option name='rdbms' value='ORACLE'> ORACLE </option>\n") ;
	        print( "<option name='rdbms' value='MAXDB'> MAXDB </option>\n") ;
	        print( "<option name='rdbms' value='MYSQL'> MYSQL </option>\n") ;
	        print( "<option name='rdbms' value='MSSQL'> MSSQL </option>\n") ;
	        print( "<option name='rdbms' value='DB2'> DB2 </option>\n") ;
	        print( "<option name='rdbms' value='HANA'> HANA </option>\n") ;
	        print(" </select></td></tr>" );
	        print( "<tr><td>App:</td><td>");
	        print( "<select name='app' class='$cssclass comboadd'>\n" );
	        print( "<option name='app' value=''></option> ");
	        $results = $sqlQuery->execLit( "select app from db_info where app not like '' group by app order by app", 0);
                if( $sqlQuery->getCount() > 0 ){
                    for( $row = 0; $row < $sqlQuery->getCount(); $row++ ){ print "<option name='app' value='" . $results[$row]['app'] . "' > " . $results[$row]['app'] . " </option> "; }
	        }
	        print(" </select></td></tr>" );
	        print( "<tr><td>Owner:</td><td>" );
	        print( "<select name='owner' class='$cssclass comboadd'>\n" );
	        print( "<option name='owner' value=''></option> ");
	        $results = $sqlQuery->execLit( "select owner from host_info where owner not like '' group by owner order by owner", 0);
                if( $sqlQuery->getCount() > 0 ){
                    for( $row = 0; $row < $sqlQuery->getCount(); $row++ ){ print "<option name='owner' value='" . $results[$row]['owner'] . "' > " . $results[$row]['owner'] . " </option> "; }
	        }
	        print(" </select></td></tr>" );	
	        print( "<tr><td>OS User:</td><td><input type='text' name='osuser' class='$cssclass' value='' /></td></tr> ");
	        print("</table>\n" );
	        print "<input type='hidden' name='hkey' value='" . $hostObj->getKey() . "' \>\n";
	        print( "<input type='hidden' name='dkey' value='0' \>\n" );
	        print( "<input type='hidden' name='confirm' value='0' \>\n" );
                $step = 'createdb';
            }
            elseif(($dbObj->getKey() < 1) && ($confirm == '0') && ($hostObj->getKey() > 0)){
                // This would be a new db, prompting to confirm	
	        $cssclass = 'ui-corner-all ui-state-disabled';   
	        if( $host == '' ){ 
	            print( "<div>DB Name too short, please try again</div>" );                    
                    print "<input type='hidden' name='skey' value='" . $hostObj->getKey() . "' \>\n";
	            print( "<input type='hidden' name='dkey' value='0' \>\n" );
	            print( "<input type='hidden' name='confirm' value='' \>\n" ); 
	            $step = 'createdb';	            
                }
                else{
                    print( "<div>Confirm new DB $db on $host</div>\n");
	            print( "<div><table class='update-table'>\n");
	            print( "<tr><td>Name:</td><td><input type='text' name='db' class='$cssclass' value='$db' readonly /></td></tr> ");
	            print( "<tr><td>RDBMS:</td><td><input type='text' name='rdbms' class='$cssclass' value='$rdbms' readonly /></td></tr>" );
	            print( "<tr><td>App:</td><td><input type='text' name='os' class='$cssclass' value='$app' readonly /></td></tr>");
	            print( "<tr><td>Owner:</td><td><input type='text' name='owner' class='$cssclass' value='$owner' readonly /></td></tr>");
	            print( "<tr><td>OS User:</td><td><input type='text' name='osuser' class='$cssclass' value='$osuser' readonly /></td></tr>");
	            print("</table>\n");
	            print "<input type='hidden' name='hkey' value='" . $hostObj->getKey() . "' \>\n";
	            print( "<input type='hidden' name='dkey' value='0' \>\n" );
	            print( "<input type='hidden' name='confirm' value='1' \>\n" ); 
	        $step = 'createdb';                 
                }	                            
            }
            elseif(($dbObj->getKey() < 1) && ($confirm == '1') && ($hostObj->getKey() > 0)){
                // This is a new host, confirmed. Create the new host
                $dkey = $dbObj->create($hostObj->getKey(), $rdbms, $db, '', 'y', '', $app, $osuser, $owner);
                if( $dkey < 1 ){ print( "Error creating DB" ); }
                else{ print( "DB created" ); }
                print "<input type='hidden' name='hkey' value='" . $hostObj->getKey() . "' \>\n";
                print( "<input type='hidden' name='dkey' value='$dkey' \>\n" );
	        print( "<input type='hidden' name='confirm' value='1' \>\n" );
	        print( "<input type='hidden' name='host' value='$host' \>\n" );
	        print( "<input type='hidden' name='db' value='$db' \>\n" );
                $step = 'done';
            }
            else{
                // Existing DB, hop to confirm
                $step = 'confirmdb';
                itemWizard($step, $input);
            }
            print( "<input type='hidden' name='step' value='$step' \>\n" );
        break;   
        
        case "createhost":
            // Create a new host
            $confirm   = isset($input['confirm']) ? $input['confirm'] : '';
            $host      = isset($input['host'])    ? $input['host']    : '';
            $server    = isset($input['server'])  ? $input['server']  : '';
            $serial    = isset($input['serial'])  ? $input['serial']  : '';
            $ip        = isset($input['ip'])      ? $input['ip']      : '';
            $os        = isset($input['os'])      ? $input['os']      : '';
            $owner     = isset($input['owner'])   ? $input['owner']   : '';
            $skey      = isset($input['skey'])    ? $input['skey']    : '';
            $hkey      = isset($input['hkey'])    ? $input['hkey']    : '';

            $serverObj = new Server($server);
            $hostObj   = new Host($host);
            $cssclass  = 'ui-corner-all';
            
            if( $serverObj->getKey() < 1 ){
                if( $skey != '' ){
                    $server = $sqlQuery->execLit("select servername from sys_info where skey = '$skey'", 1, 1);
                    $serverObj = new Server($server);
                }
                else{
                    // No valid server was picked for this host
                    print( "<div>Unable to find server $server, please try again</div>" );
                    $step = 'pickserver'; 
                }            
            }
            
            if(($hostObj->getKey() < 1) && ($confirm == '') && ($serverObj->getKey() > 0)){ 
                // This would be a new host, unconfirmed
                print( "<div>Create new host on $server</div>\n");
	        print( "<div><table class='update-table'>\n");
	        print( "<tr><td>Name:</td><td><input type='text' name='host' class='$cssclass' value='' /></td></tr> ");
	        print( "<tr><td>IP Add:</td><td><input type='text' name='ip' class='$cssclass'></td></tr>" );
	        print( "<tr><td>OS:</td><td>");
	        print( "<select name='os' class='$cssclass comboadd'>\n" );
	        print( "<option name='os' value=''></option> ");
	        print( "<option name='os' value='AIX'> AIX </option>\n") ;
	        print( "<option name='os' value='LINUX'> LINUX </option>\n") ;
	        print( "<option name='os' value='WINDOWS'> WINDOWS </option>\n") ;
	        print( "<option name='os' value='SOLARIS'> SOLARIS </option>\n") ;
	        print( "<option name='os' value='HPUX'> HPUX </option>\n") ;
	        print(" </select></td></tr>" );
	        print( "<tr><td>Owner:</td><td>" );
	        print( "<select name='owner' class='$cssclass comboadd'>\n" );
	        print( "<option name='owner' value=''></option> ");
	        $results = $sqlQuery->execLit( "select owner from host_info where owner not like '' group by owner order by owner", 0);
                if( $sqlQuery->getCount() > 0 ){
                    for( $row = 0; $row < $sqlQuery->getCount(); $row++ ){ print "<option name='owner' value='" . $results[$row]['owner'] . "' > " . $results[$row]['owner'] . " </option> "; }
	        }
	        print(" </select></td></tr>" );	        
	        print("</table>\n" );
	        print "<input type='hidden' name='skey' value='" . $serverObj->getKey() . "' \>\n";
	        print( "<input type='hidden' name='hkey' value='0' \>\n" );
	        print( "<input type='hidden' name='confirm' value='0' \>\n" );
                $step = 'createhost';
            }
            elseif(($hostObj->getKey() < 1) && ($confirm == '0') && ($serverObj->getKey() > 0)){
                // This would be a new host, prompting to confirm	
	        $cssclass = 'ui-corner-all ui-state-disabled';   
	        if( $host == '' ){ 
	            print( "<div>Hostname too short, please try again</div>" );                    
                    print "<input type='hidden' name='skey' value='" . $serverObj->getKey() . "' \>\n";
	            print( "<input type='hidden' name='hkey' value='0' \>\n" );
	            print( "<input type='hidden' name='confirm' value='' \>\n" ); 
	            $step = 'createhost';	            
                }
                else{
                    print( "<div>Confirm new host $host on $server</div>\n");
	            print( "<div><table class='update-table'>\n");
	            print( "<tr><td>Name:</td><td><input type='text' name='host' class='$cssclass' value='$host' readonly /></td></tr> ");
	            print( "<tr><td>IP Add:</td><td><input type='text' name='ip' class='$cssclass' value='$ip' readonly /></td></tr>" );
	            print( "<tr><td>OS:</td><td><input type='text' name='os' class='$cssclass' value='$os' readonly /></td></tr>");
	            print( "<tr><td>Owner:</td><td><input type='text' name='owner' class='$cssclass' value='$owner' readonly /></td></tr>");
	            print("</table>\n");
	            print "<input type='hidden' name='skey' value='" . $serverObj->getKey() . "' \>\n";
	            print( "<input type='hidden' name='hkey' value='0' \>\n" );
	            print( "<input type='hidden' name='confirm' value='1' \>\n" ); 
	        $step = 'createhost';                 
                }	                  
            }
            elseif(($hostObj->getKey() < 1) && ($confirm == '1') && ($serverObj->getKey() > 0)){
                // This is a new host, confirmed. Create the new host
                $hkey = $hostObj->create($ip, $serverObj->getSerial(), '', 'y', $os, $owner);
                if( $hkey < 1 ){ print( "Error creating host" ); }
                else{ print( "Host created" ); }
                print "<input type='hidden' name='skey' value='" . $serverObj->getKey() . "' \>\n";
                print( "<input type='hidden' name='hkey' value='$hkey' \>\n" );
	        print( "<input type='hidden' name='confirm' value='1' \>\n" );
	        print( "<input type='hidden' name='server' value='$server' \>\n" );
	        print( "<input type='hidden' name='host' value='$host' \>\n" );
                $step = 'done';
            }
            else{
                // Existing server, hop to confirm
                $step = 'confirmhost';
                itemWizard($step, $input);
            }
            print( "<input type='hidden' name='step' value='$step' \>\n" );          
        break;
        
        case "confirmserver":    
            // Confirm this is the proper server    
            $cssclass = 'ui-corner-all';
            $confirm  = isset($input['confirm'])   ? $input['confirm']    : '';
            $newsrv   = isset($input['newserver']) ? $input['newserver']  : '';
            $currsrv  = isset($input['currserver'])? $input['currserver'] : '';
            $server   = isset($input['server'])    ? $input['server']     : '';
            $confirm  = isset($input['confirm'])   ? $input['confirm']    : '';
            $mode     = isset($input['mode'])      ? $input['mode']    : '';
            if($server == ''){
                if(($newsrv != '') && ($currsrv == 'new')){$server = $newsrv;}
                else{ $server = $currsrv; }
            }
            $serverObj = new Server($server);
            if( $serverObj->getKey() < 1 ){ print "Invalid server $server"; return; }
            
            if( $confirm == '1' ){ 
                // Coming from a picked host  
	        print( "<form id='update-form' class='update ui-widget' action='#' method='post'>\n" );  
	        print( "<div>Confirm Server $server</div>\n");
	        print( "<table id='update-table' class='ui-widget-content ui-widget-content ui-corner-all text update-table'>\n");	    
	        print( " <tr><td><label for='ip'>IP:<td><td class='$cssclass'>" . $serverObj->getIP() . "</td>\n </tr>\n" );
	        print( " <tr><td><label for='manuf'>Make:<td><td class='$cssclass'>" . $serverObj->getManuf() . "</td>\n </tr>\n" );
	        print( " <tr><td><label for='owner'>Owner:<td><td class='$cssclass'>" . $serverObj->getGroup() . "</td>\n </tr>\n" );
	        print( " <tr><td><label for='dc'>Datacenter:<td><td class='$cssclass'>" . $serverObj->getDC() . "</td>\n </tr>\n" );
	        print( "<input type='hidden' name='confirm' value='' \>\n" ); 
	        print( "<input type='hidden' name='skey' value='" . $serverObj->getKey() . "' \>\n" ); 
	        print( "<input type='hidden' name='server' value='" . $serverObj->getName() . "' \>\n" );
	        if( $mode == 'hoststart' ){ $step = 'createhost';}
	        elseif( $mode == 'serverstart' ){ $step = 'done';}
	    }
	    else{
	        print( "confirm was $confirm");
	    }
	    print( "<input type='hidden' name='step' value='$step' \>\n" );
        break;
        
        case "confirmdb":
            // Confirm this is the proper DB
            $host      = isset($input['host'])    ? $input['host']    : '';
            $db        = isset($input['db'])      ? $input['db']      : '';
            $owner     = isset($input['owner'])   ? $input['owner']   : '';
            $rdbms     = isset($input['rdbms'])   ? $input['rdbms']   : '';
            $app       = isset($input['app'])     ? $input['app']     : '';
            $osuser    = isset($input['osuser'])  ? $input['osuser']  : '';
            $hkey      = isset($input['hkey'])    ? $input['hkey']    : '';
            $dkey      = isset($input['dkey'])    ? $input['dkey']    : '';
            $hostObj   = new Host($host);
            $dbObj     = new Database($db);
            if( $dbObj->getKey() < 1 ){ print "Invalid DB $db"; return; }
            print( "<form id='update-form' class='update ui-widget' action='#' method='post'>\n" );  
	    print( "<div>Confirm DB $db</div>\n");
	    print( "<table id='update-table' class='ui-widget-content ui-widget-content ui-corner-all text update-table'>\n");	    
	    print( " <tr><td><label for='rdbms'>RDBMS:<td><td class='$cssclass'>" . $dbObj->getRDBMS() . "</td>\n </tr>\n" );
	    print( " <tr><td><label for='app'>App:<td><td class='$cssclass'>" . $dbObj->getApp() . "</td>\n </tr>\n" );
	    print( " <tr><td><label for='owner'>Owner:<td><td class='$cssclass'>" . $dbObj->getGroup() . "</td>\n </tr>\n" );
	    print( " <tr><td><label for='osuser'>OS User:<td><td class='$cssclass'>" . $dbObj->getOSUser() . "</td>\n </tr>\n" );
	    print( " <tr><td><label for='host'>Host:<td><td class='$cssclass'>" . $dbObj->getServer() . "</td>\n </tr>\n" ); 
	    print( "<input type='hidden' name='dkey' value='" . $dbObj->getKey() . "' \>\n" ); 
	    print( "<input type='hidden' name='hkey' value='" . $hostObj->getKey() . "' \>\n" );
	    
	    // Jump based on mode
	    if( $mode == 'dbstart' ){ $step = 'done'; }
	    else{ $step = 'done'; }
            print( "<input type='hidden' name='step' value='$step' \>\n" );
        break;
        
        case "confirmhost":    
            // Confirm this is the proper host    
            $cssclass = 'ui-corner-all';
            $confirm  = isset($input['confirm']) ? $input['confirm'] : '';
            $server   = isset($input['server'])  ? $input['server']  : '';
            $host     = isset($input['host'])    ? $input['host']    : '';
            $hostObj  = new Host($host);
            if( $server == '' ){ $server = $hostObj->getServer(); }
            if( $hostObj->getKey() < 1 ){ print "Invalid host $host"; return; }
            $serverObj = new Server($server);
	    print( "<form id='update-form' class='update ui-widget' action='#' method='post'>\n" );  
	    print( "<div>Confirm Host $host</div>\n");
	    print( "<table id='update-table' class='ui-widget-content ui-widget-content ui-corner-all text update-table'>\n");	    
	    print( " <tr><td><label for='ip'>IP:<td><td class='$cssclass'>" . $hostObj->getIP() . "</td>\n </tr>\n" );
	    print( " <tr><td><label for='os'>OS:<td><td class='$cssclass'>" . $hostObj->getOS() . "</td>\n </tr>\n" );
	    print( " <tr><td><label for='owner'>Owner:<td><td class='$cssclass'>" . $hostObj->getGroup() . "</td>\n </tr>\n" );
	    print( " <tr><td><label for='dc'>Datacenter:<td><td class='$cssclass'>" . $hostObj->getDC() . "</td>\n </tr>\n" );
	    print( " <tr><td><label for='server'>Server:<td><td class='$cssclass'>" . $hostObj->getServer() . "</td>\n </tr>\n" ); 
	    print( "<input type='hidden' name='skey' value='" . $hostObj->getKey() . "' \>\n" ); 
	    print( "<input type='hidden' name='hkey' value='" . $hostObj->getKey() . "' \>\n" );
	    print( "<input type='hidden' name='server' value='" . $hostObj->getName() . "' \>\n" );
	    
	    // Jump based on mode
	    if( $mode == 'hoststart' ){ 
	        $step = 'done'; 
	    }
	    elseif( $mode == 'dbstart' ){ 
	        print( "<input type='hidden' name='confirm' value='' \>\n" );
	        print( "<input type='hidden' name='hkey' value='" . $hostObj->getKey() . "' \>\n" );
	        
	        $step = 'createdb'; 
	    }
	    elseif( $mode == 'serverstart' ){ 
	        $step = 'done'; 
	    }
	    print( "<input type='hidden' name='step' value='$step' \>\n" );
        break;
        
        default:
            print( "<div>Adding new manual $step is not supported yet</div>\n");
        
    }
    print( "<input type='hidden' name='objtype' value='wizard' \><input type='hidden' name='mode' value='$mode' \>\n" );
    print( "</td></tr>\n" );	    
    print( "</table\n");
    print( "</form>" );
}


function insDetail($type, $filter='%', $level){
    // Display a detailed editable table for a system, host, database, or other resource
    $sqlQuery = new Query();
    $filter = fixSQL($filter);
    print( "Inserting detail - got $type, $filter ") ; 
    if( $type == 'host' ){ 
        if( $filter == '%' ){ $filter = $sqlQuery->execLit("select hostname from host_info", 1, 1); }
        $res = new Host($filter); 
    }
    elseif( $type == 'hostkey' ){
        //Keep the hosts in bounds
        if( $filter < 1 ){ $filter = 1; }
        if( $sqlQuery->execLit("select count(*) from host_info where hkey = $filter", 1, 1) < 1 ){
            //Grab the next host
            print( "Grabbing next ID because $filter doesn't exist");
            $filter = $sqlQuery->getNextId('host_info',$filter);       
        }
        $res = new Host($sqlQuery->execLit("select hostname from host_info where hkey = $filter", 1, 1));       
    }
    elseif( $type == 'server' ){
        if( $filter == '%' ){ $filter = $sqlQuery->execLit("select servername from sys_info", 1, 1); }
        $res = new Server($filter); 
    }
    elseif( $type == 'db' ){
        if( $filter == '%' ){ $filter = $sqlQuery->execLit("select dbname from db_info", 1, 1); }
        $res = new Database($filter); 
    }
    elseif( $type == 'dbkey' ){
        //Keep the DBs in bounds
        if( $filter < 1 ){ $filter = 1; }
        if( $sqlQuery->execLit("select count(*) from db_info where dkey = $filter", 1, 1) < 1 ){
            //Grab the next db
            print( "Grabbing next ID because $filter doesn't exist");
            $filter = $sqlQuery->getNextId('db_info',$filter);       
        }
        $res = new Database($sqlQuery->execLit("select dbname from db_info where dkey = $filter", 1, 1));
    }
    elseif( $type == 'person' ){
        if( $filter == '%' ){ $filter = $sqlQuery->execLit("select resname from res_info", 1, 1); }
        //TODO: No human class yet $res = new Person($filter); 
    }
    elseif( $type == 'personkey' ){
        $res = new Person($sqlQuery->execLit("select resname from res_info where rkey = $filter", 1, 1)); 
        //TODO: No human class yet $res = new Person($filter); 
    }
    elseif( $type == 'searchhost' ){
        // Handle the generics - make all strings searchable, etc. Condense double/triple % down to one %
        $filter = str_replace("*", "", $filter);
        $filter = str_replace("%%", "", $filter);
        $filter = str_replace("%%", "", $filter);
        if( $filter == '%' ){ 
            $filter = $sqlQuery->execLit("select hostname from host_info", 1, 1);
            $res = new Host($filter);          
        }
        else{
            // Now, ideally, I want to return every host that has 'filter' anywhere. Start small with one field at a time
            //TODO: Massively improve this
            $sqlQuery->execLit("select hostname from host_info where hostname like '%$filter%'");
            if( $sqlQuery->getCount() > 1 ){
                // Found several hosts - need to figure out a way to loop through them
            }
            elseif( $sqlQuery->getCount() < 1 ){
                // Go fishing
                //TODO: finish this
                $sqlQuery->execLit("select hostname from host_info where owner like $filter");
                $sqlQuery->execLit("select hostname from host_info where comments like $filter");
                $sqlQuery->execLit("select hostname from host_info where app like $filter");
                $sqlQuery->execLit("select hostname from host_info where appinst like $filter");
            }
            elseif( $sqlQuery->getCount() == 1 ){ /* We're good - just let it ride */ }
            print "Found " . $sqlQuery->getCount() . " records for $filter";
            $res = new Host($filter); 
        }
    }
    else{ print( "not sure what to do - got $type, $filter, $level"); return; }
    
    
    // Insert the edit/reset buttons at the top of the form
    print( "\t<div id='resdetailtable' ><form id='resource-form' class='skills' action='#' method='post'>\n" );
    print "<button id='reseditbutton' class='resbutton ui-widget edit resedit secure' title='Edit' alt='" . $res->getKey() . "'><span id='editsubmit' class='ui-button-text ui-button-icon-primary ui-icon ui-icon-pencil resedit' alt='" . $res->getKey() . "'>Edit</span></button>\n";   
    print "<button id='resresetbutton' class='resbutton ui-widget edit resreset' title='Reset' alt='" . $res->getKey() . "'><span id='editsubmit' class='ui-button-text ui-button-icon-primary ui-icon ui-icon-cancel resreset' alt='" . $res->getKey() . "'>Reset</span></button>\n";
    
    // Insert the resource details    
    print( "\t<div id='tablewrapper' class='ui-corner-all'>\n" );
    print( "\t<table class='main-table detail-table'>\n");
    print "\t<caption class='table-caption' >" . $res->getName() . "</caption>\n";
    print( "\t\t<thead class='detail-table' ><tr><th>Item</th><th>Value</th></tr></thead><tbody>\n" );
    print("<tr><td colspan='2'><div class='scrollcontent'>\n");
    print( "\t\t<table class='footable main-table' id='detailtable' summary='Details'>\n" );
    if( $res->getKey() < 1 ){
        print( "<tr><td>No results found</td>\n</tr>\n</table>\n</form></div></div>\n" );
	return;
    }
    else{             
	print( "\t\t<tbody>\n" );
        $level == '' ? $res->printForm() : $res->printTRLong(); 
        print( "\t\t</tbody>\n\t</table>\n" );
        print( "\t</div></td></tr></tbody></table>");
        
        //Submit/Rest buttons in their own table
        print("\t\t<table style='margin-left:35%; width:12em;'>\n");
        print "\t\t<tr class='hidden ui-corner-all res-edit bg-clear'>\n <td></td><td><button class='fg-button ui-state-default ui-priority-primary ui-corner-all reseditsubmit secure' alt='" . $res->getKey() . "'><span id='reseditsubmit' class='ressubmit' alt='" . $res->getKey() . "'>Update</span></button> <button class='fg-button ui-state-default ui-priority-primary ui-corner-all resreset' alt='" . $res->getKey() . "'><span id='editsubmit' class='resreset' alt='" . $res->getKey() . "'>Reset</span></button> </td></tr>\n" ;          
        print( "\t</table>\n" );

        print( "\t<input type='hidden' name='objtype' value='upditem' \>\n" );
        print( "\t<input type='hidden' name='type' value='$type' \>\n" );
        print "\t<input type='hidden' name='objname' value='" . $res->getName() . "' \>\n" ;
	print( "\t<input type='hidden' name='rkey' value='" . $res->getKey() . "' \>\n" );           
        print( "\t</form></div></div> \n" );  
    }
}


?>


