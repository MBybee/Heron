<?php
 // This is part of the Heron Enterprise Management Suite for OpenEngine.Org
 // This program is the web-based mid-tier for a server and db workflow management app
 // Version 0.1
 // All code and graphics © Copyright 2005-2013 Mike Bybee, OpenEngine.Org
 // All rights reserved.
 // This app is distributed under the BSD simplified license.
 // You may obtain a copy of the License at:
 // http://openengine.org/license.html 
 // Included libraries may be under LGPL or MIT licenses.
 // Libraries and Plugins Copyright their respective owners. See the libraries for their licenses.
 // PHP 5+
 // class definition
class Query {
    // This is a base class that allows me to simplify some stuff I found I kept doing repetitively
    // such as the query-string building, row counting, limit, and db param passing.
    // Going to slowly phase this in as needed.
    public $filter;
    public $query;
    public $sql;
    public $count;
    public $limit;
    public $orderby;
    public $single;
    
    public function __construct() { 
        $this->count = -1;
    }
    
    public function exec($query, $filter='%', $orderby='', $limit='100000', $single='') {
        // Executes a query, sets the global count, and returns an array with the results
        // Optionally, set $single to anything to get back just the very first item in the first row
        global $dbtype;
        global $dbname;
        $results  = array();
        $filterby = '';        
        $limit    = $limit > 0 ? $limit : 100000;
        
        // Translate the named query into a sql string
        // Split filter on space to allow searches like "ip 127.0.0.1" or "owner: mike"
        if( strpos($filter, ' ') > -1 ){
	    $tmp      = preg_split('/\s/', $filter); 
	    $filterby = $tmp[0];
	    $filter   = $tmp[1]; 
        }
        // Replace * in filter with %, in case people try that syntax
        $filter = str_replace("*", "%", $filter);
        $this->sql = getSQL( $dbtype, $query, $filter, $filterby, $orderby );
        
        if( $dbtype == "mysql" ){
            // Done here because limit is different for different DBs.
            $this->sql = $this->sql . " limit 0,$limit";
            global $dbhost;
            global $dbuser;
            global $dbpass;
            global $dbport;
            $dbh = new PDO("$dbtype:host=$dbhost;port=$dbport;dbname=$dbname",$dbuser,$dbpass);
            $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
            $sth = $dbh->prepare($this->sql);
            $sth->execute();
            while( $row = $sth->fetch(PDO::FETCH_ASSOC) ){ array_push( $results, $row ); }
        }
        elseif( $dbtype == "sqlite" ){	
	    //$sql = 'select sqlite_version()';
	    //$sql = 'SELECT name FROM sqlite_master WHERE type = "table"';
	    //$sql = 'SELECT * FROM sqlite_master WHERE type = "table"';
	    $sql = $query . " limit $limit";
	    $dbh = new PDO("$dbtype:$dbname");
            $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);      
            $sth = $dbh->prepare($sql);
            $sth->execute();    
            while( $row = $sth->fetch(PDO::FETCH_ASSOC) ){ array_push( $results, $row ); }
        }
        $this->count = count($results);
        $this->single = $results[0][key($results[0])];
        $val = $single == '' ? $results : $this->single;
        return $val;
    }
    
    public function execLit($sql, $limit='100000', $single='') {
        // Executes a LITERAL query, sets the global count, and returns an array with the results       
        // Optionally, set $single to anything to get back just the very first item in the first row
        // This is only used for SQL built within the app, that is to say, trusted SQL.
        global $dbtype;
        global $dbname;
        $results   = array();
        $limit     = $limit > 0 ? $limit : 100000;
        $this->sql = $sql;
        
        if( $dbtype == "mysql" ){
            // Done here because limit is different for different DBs.
            $this->sql = $this->sql . " limit 0,$limit";
            //print "SQL: " . $this->sql;
            global $dbhost;
            global $dbuser;
            global $dbpass;
            global $dbport;
            $dbh = new PDO("$dbtype:host=$dbhost;port=$dbport;dbname=$dbname",$dbuser,$dbpass);
            $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);
            $sth = $dbh->prepare($this->sql);
            $sth->execute();
            while( $row = $sth->fetch(PDO::FETCH_ASSOC) ){ array_push( $results, $row ); }
        }
        elseif( $dbtype == "sqlite" ){	
	    //$sql = 'select sqlite_version()';
	    //$sql = 'SELECT name FROM sqlite_master WHERE type = "table"';
	    //$sql = 'SELECT * FROM sqlite_master WHERE type = "table"';
	    $sql = $query . " limit $limit";
	    $dbh = new PDO("$dbtype:$dbname");
            $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING);      
            $sth = $dbh->prepare($sql);
            $sth->execute();    
            while( $row = $sth->fetch(PDO::FETCH_ASSOC) ){ array_push( $results, $row ); }
        }
        $this->count = count($results);
        if( $this->count > 0 ){$this->single = $results[0][key($results[0])];}
        else{$single='';}
        $val = $single == '' ? $results : $this->single;
        return $val;
    }
    
    public function getCount(){
        // Get count of rows from most recent query
        return $this->count;
    }
    
    public function getSingle(){
        // Get the first item in the first row from the most recent query
        return $this->single;
    }
    
    public function getNextId($table='host_info', $start = 1){
        // This is to deal with the rather inevitable gaps in a sequence
        // It returns the next possible key - which may be lower than the one provided
        $results = array();
        switch($table){
            case "host_info":
                $key = 'hkey';
                break;
            case "db_info":
                $key = 'dkey';
                break;
            default:
                $key = 'skey';        
        }
        
        // Fairly complex SQL that finds missing items, returns id, next_id, missing_inbetween, or no results
        $sql = "SELECT a AS id, b AS next_id, (b - a) -1 AS missing_inbetween" .  
          "FROM ( SELECT a1.$key AS a , MIN(a2.$key) AS b " .
            "FROM $table  AS a1 LEFT JOIN $table AS a2 ON a2.$key > a1.$key " .
            "WHERE a1.$key >= $start -1 GROUP BY a1.$key ) AS tab " .
          "WHERE b > a + 1";
        // Find out if we've been called needlessly first:
        if( $this::execLit("select count(*) from $table where $key = $start", 1, 1) > 0 ){ $this->single = $start; return $start; }
        elseif( $this::execLit("select max($key) from $table", 1, 1) <= $start ){ return $this->single; }
        else{ $results = $this::execLit($sql); return( $results[0]['next_id'] ); }
    }

}
class Resource {
    // Almost all of the objects will inherit resource - users, databases, servers, hosts, etc
    // define properties
    public $name;
    public $lastupdate;
    public $active;
    public $comments;
    public $key;
    public $email;
    public $group;
    public $dateact;
    public $manual;
    
    public function __construct($name) {
        $this->name = $name;
    }

    // methods - all gets, no sets at this level 
    public function getName() {
        return $this->name;
    }
    
    public function getActive() {
        return $this->active;
    }
    
    public function getComments() {
        return $this->comments;
    }
    
    public function getLastUpdate() {
        return $this->lastupdate;
    }
    
    public function getDateAct() {
        return $this->dateact;
    }
    
    public function getKey() {
        return $this->key;
    }
    
    public function getEmail() {
        return $this->email;
    }
    
    public function getGroup() {
        return $this->group;
    }
    
    public function getManual() {
        return $this->manual;
    }

    public function printAll() {
        foreach($this as $key => $value) {
           print "$key => $value\n";
        }
    }
    
    public function printTRLong() {
        foreach($this as $key => $value) {
           print "<tr><td>$key</td><td>$value</td></tr>\n";
        }
    }
    
    public function printTRShort() {
        // This one is implemented in each sub class
    }    
}


class Server extends Resource {    
    //name, key, group, email, dateact, manual, lastupdate, comments, live/active inherited
    public $model;   
    public $manuf;
    public $cpu;
    public $cpunum;
    public $cluster;
    public $ram;
    public $swap;
    public $hbanum;
    public $rack;
    public $datacenter;
    public $ip;
    public $isr;
    public $rownum;
    public $serial;
    public $audit;
    public $floor;
    public $room;   
    
    private $sql;

    public function __construct($name) {
        parent::__construct($name);
        $this::init();
    } 
    
    public function init($verbose=''){
        $results = array();
        $sqlQuery = new Query();
        if( $this->key == '' ){
            $results = $sqlQuery->execLit("select i.skey, serial, lastupdate, i.servername, model, manuf, cpu, cpunum, cluster, ram, swap, hbanum, rack, datacenter, owner, comments, ip, isr, rownum, datertu, support_mail, man_update, live, audit, floor, room from sys_info i, sys_key k where i.servername='$this->name' and k.skey = i.skey ", 0);            
        }
        else{
            // Query based on key - much better, mostly used when just re-syncing
            $results = $sqlQuery->execLit("select i.skey, serial, lastupdate, i.servername, model, manuf, cpu, cpunum, cluster, ram, swap, hbanum, rack, datacenter, owner, comments, ip, isr, rownum, datertu, support_mail, man_update, live, audit, floor, room from sys_info i, sys_key k where name like '%$this->name%' and k.skey = '$this->key' and k.skey = i.skey ", 0);
        }
        if( $sqlQuery->getCount() <= 0 ){ 
            if($verbose != ''){ print "No server of name " . $this->name . " exists <br />\n"; }
            return 0;
        }
        else{
            // In the case of duplicates, we're just going to use the first - but warn if verbose
            if(($sqlQuery->getCount() > 1) && ($verbose != '')){ print "Duplicate servers with the name " . $this->name . " exist! <br />\n"; }
            
            $this->key        = $results[0]['skey'];
            $this->lastupdate = $results[0]['lastupdate'];
            $this->model      = $results[0]['model'];   
            $this->manuf      = $results[0]['manuf'];
            $this->cpu        = $results[0]['cpu'];
            $this->cpunum     = $results[0]['cpunum'];
            $this->cluster    = $results[0]['cluster'];
            $this->ram        = $results[0]['ram'];
            $this->swap       = $results[0]['swap'];
            $this->hbanum     = $results[0]['hbanum'];
            $this->rack       = $results[0]['rack'];
            $this->datacenter = $results[0]['datacenter'];
            $this->group      = $results[0]['owner'];
            $this->ip         = $results[0]['ip'];
            $this->isr        = $results[0]['isr'];
            $this->rownum     = $results[0]['rownum'];
            $this->dateact    = $results[0]['datertu'];
            $this->email      = $results[0]['support_mail'];  
            $this->serial     = $results[0]['serial'];
            $this->audit      = $results[0]['audit'];   
            $this->manual     = $results[0]['man_update'];
            $this->active     = $results[0]['live'];
            $this->comments   = $results[0]['comments'];
            $this->floor      = $results[0]['floor'];
            $this->room       = $results[0]['room'];
            
            // Convert 'booleans' if the DB returns 0/1
            $this->active = str_replace("1", "y", $this->active);
            $this->active = str_replace("0", "n", $this->active);
            $this->audit  = str_replace("1", "y", $this->audit);
            $this->audit  = str_replace("0", "n", $this->audit);
            $this->manual = str_replace("1", "y", $this->manual);
            $this->manual = str_replace("0", "n", $this->manual);
            
            return($sqlQuery->getCount());
        }
    }
    
    public function create(){
        print( "Creation disabled temporarily" );
        return(0);
    }
    public function update(){
        print( "Updating disabled temporarily" );
        return(0);
    }
    
    // Get/Set functions - roughly alphabetical order, grouped get/set
    public function getAudit(){
        return $this->audit;
    }    
    public function setAudit($audit){
        $this->audit = fixSQL($audit);
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');        
        $sqlQuery->execLit( "update sys_key set audit = '$this->audit' where servername='$this->name' and skey='$this->key' " ); 
        $sqlQuery->execLit( "update sys_info set lastupdate = '$now' where servername='$this->name' and skey='$this->key' " );       
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->audit;
    }
    
    //getComments inherited
    public function setComments($comments){
        $this->comments = fixSQL($comments);
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');        
        $sqlQuery->execLit( "update sys_info set comments = '$this->comments', lastupdate = '$now' where servername='$this->name' and skey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->comments;
    }
    
    public function getDC(){
        return $this->datacenter;
    }
    public function setDC($dc){
        $this->datacenter = fixSQL($dc);
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');        
        $sqlQuery->execLit( "update sys_info set datacenter = '$this->datacenter', lastupdate = '$now' where servername='$this->name' and skey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->datacenter;
    }
    
    //getGroup inherited
    public function setGroup($group){
        $this->group = fixSQL($group);
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');        
        $sqlQuery->execLit( "update sys_info set owner = '$this->owner', lastupdate = '$now' where servername='$this->name' and skey='$this->key' " );        
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->group;
    }
    
    //No setHosts - this is a read only function
    public function getHosts(){
        // This gets all the hosts that say they depend on this server (especially useful for VM hosts)
        $results = array();
        $sqlQuery = new Query();
        $results = $sqlQuery->execLit( "select i.hkey, i.hostname, k.live, i.owner from host_info i, host_key k where skey = '$this->key'  and i.hkey = k.hkey" , 0);    
        return $results;
    }
    
    public function getIP(){
        return $this->ip;
    }    
    public function setIP($ip){
        $this->ip = fixSQL($ip);
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');        
        $sqlQuery->execLit( "update sys_info set ip = '$this->ip', lastupdate = '$now' where servername='$this->name' and skey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->ip;
    }
    
    public function getManuf(){
        return $this->manuf;
    }
    public function setManuf($manuf){
        $this->manuf = fixSQL($manuf);
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');        
        $sqlQuery->execLit( "update sys_info set manuf = '$this->manuf', lastupdate = '$now' where servername='$this->name' and skey='$this->key' " );        
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->manuf;
    }
    
    public function getSerial(){
        return $this->serial;
    }
    //No setSerial at the moment
    
    //Output functions
    public function printTRShort() {
        // Just print the most common ones
        print "<tr><td>Systemname</td><td>" . $this->name       . "</td></tr>\n";
        print "<tr><td>IP</td><td>"         . $this->ip         . "</td></tr>\n";
        print "<tr><td>Model</td><td>"      . $this->model      . "</td></tr>\n";
        print "<tr><td>Manuf</td><td>"      . $this->manuf      . "</td></tr>\n";
        print "<tr><td>CPU</td><td>"        . $this->cpu        . "</td></tr>\n";
        print "<tr><td>Serial</td><td>"     . $this->serial     . "</td></tr>\n";
        print "<tr><td>Datacenter</td><td>" . $this->datacenter . "</td></tr>\n";
        print "<tr><td>RAM</td><td>"        . $this->ram        . "</td></tr>\n";
        print "<tr><td>Swap</td><td>"       . $this->swap       . "</td></tr>\n";
        print "<tr><td>Rack</td><td>"       . $this->rack       . "</td></tr>\n";
        print "<tr><td>Row</td><td>"        . $this->rownum     . "</td></tr>\n";
        print "<tr><td>Live</td><td>"       . $this->active     . "</td></tr>\n";
        print "<tr><td>RTU Date</td><td>"   . $this->dateact    . "</td></tr>\n";
        print "<tr><td>ISR</td><td>"        . $this->isr        . "</td></tr>\n";
        print "<tr><td>Owner</td><td>"      . $this->group      . "</td></tr>\n";
        print "<tr><td>Contact</td><td>"    . $this->email      . "</td></tr>\n";
        print "<tr><td>Manual</td><td>"     . $this->manual     . "</td></tr>\n";
        print "<tr><td>Updated</td><td>"    . $this->lastupdate . "</td></tr>\n";
        
    }
    
    public function printForm(){
        $class1 = "<td class='res-view'>";
	$class2 = "</td><td class='hidden res-edit'><input type='text' class='res-edit' name=";
	
	// Just print the most common ones
        print "<tr><td>Systemname</td>$class1" . $this->name       . "$class2 'name' value='"     . $this->name       . "' /></td></tr>\n";
        print "<tr><td>IP</td>$class1"         . $this->ip         . "$class2 'ip' value='"       . $this->ip         . "' /></td></tr>\n";
        print "<tr><td>Model</td>$class1"      . $this->model      . "$class2 'model' value='"    . $this->model      . "' /></td></tr>\n";
        print "<tr><td>Manuf</td>$class1"      . $this->manuf      . "$class2 'manuf' value='"    . $this->manuf      . "' /></td></tr>\n";
        print "<tr><td>CPU</td>$class1"        . $this->cpu        . "$class2 'cpu' value='"      . $this->cpu        . "' /></td></tr>\n";
        print "<tr><td>Serial</td>$class1"     . $this->serial     . "$class2 'serial' value='"   . $this->serial     . "' /></td></tr>\n";
        print "<tr><td>Datacenter</td>$class1" . $this->datacenter . "$class2 'dc' value='"       . $this->datacenter . "' /></td></tr>\n";
        print "<tr><td>RAM</td>$class1"        . $this->ram        . "$class2 'ram' value='"      . $this->ram        . "' /></td></tr>\n";
        print "<tr><td>Swap</td>$class1"       . $this->swap       . "$class2 'swap' value='"     . $this->swap       . "' /></td></tr>\n";
        print "<tr><td>Rack</td>$class1"       . $this->rack       . "$class2 'rack' value='"     . $this->rack       . "' /></td></tr>\n";
        print "<tr><td>Row</td>$class1"        . $this->rownum     . "$class2 'rownum' value='"   . $this->rownum     . "' /></td></tr>\n";
        print "<tr><td>Live</td>$class1"       . $this->active     . "$class2 'active' value='"   . $this->active     . "' /></td></tr>\n";
        print "<tr><td>RTU Date</td>$class1"   . $this->dateact    . "$class2 'datertu' value='"  . $this->dateact    . "' /></td></tr>\n";
        print "<tr><td>ISR</td>$class1"        . $this->isr        . "$class2 'isr' value='"      . $this->isr        . "' /></td></tr>\n";
        print "<tr><td>Owner</td>$class1"      . $this->group      . "$class2 'owner' value='"    . $this->group      . "' /></td></tr>\n";
        print "<tr><td>Contact</td>$class1"    . $this->email      . "$class2 'email' value='"    . $this->email      . "' /></td></tr>\n";
        print "<tr><td>Floor</td>$class1"      . $this->email      . "$class2 'floor' value='"    . $this->floor      . "' /></td></tr>\n";
        print "<tr><td>Room</td>$class1"       . $this->email      . "$class2 'room' value='"     . $this->room      . "' /></td></tr>\n";
        print "<tr><td>Manual</td>$class1"     . $this->manual     . "$class2 'manual' value='"   . $this->manual     . "' /></td></tr>\n";
        print "<tr><td>Updated</td>$class1"    . $this->lastupdate . "$class2 'lastupdt' value='" . $this->lastupdate . "' /></td></tr>\n";
    }
}


class Host extends Resource {
    
    //name, key, group, email, dateact, manual, lastupdate, comments, live/active inherited
    //Several of these will update underlying server objects
    public $cluster;
    public $ram;
    public $swap;
    public $datacenter;
    public $ip;
    public $ip2;
    public $ip3;
    public $ip4;
    public $ip5;
    public $ip6;
    public $isr;
    public $serial;
    public $audit;   
    public $prod;
    public $os;
    public $osver;
    public $ospatch;
    public $san;
    public $uptime;
    public $diskmon;
    public $ccmsmon;
    public $tbsmon;
    public $sapmaint;
    public $cruntime;
    public $javaver;
    public $javavend;
    public $javaverfull;
    public $mailserver;
    public $lastbackup;
    public $adminpass;
    public $itar;
    public $cronjobs;
    public $aioact;
    public $aiomin;
    public $aiomax;
    public $procmax;
    public $appinst;
    public $app;
    public $storage;
    public $virtual;
    public $skey;
    public $server;
    public $supvendor;
    public $sbu;
    public $sbe;
    public $priority;
    public $suphours;
    public $startnote;
    public $stopnote;
    public $hdd;
    public $asset;
    public $hwasset;
    public $product;
    public $vmtype;
    public $tier2;
    public $tier3;
    public $vencontact;
    public $venphone;
    public $esccontact;
    public $escphone;
    public $esc2contact;
    public $esc2phone;
    public $netname;
    public $capability;
    public $caplist;
    public $domain;
    public $cidesc;
    public $billable;
    public $instid;
    public $recid;
    public $appliance;
    public $decomdate;
    public $rack;

    
    
    private $sql;

    public function __construct($name) {
        parent::__construct($name);
        $this::init();
    }

    // define methods   
    public function init($verbose=''){
        $results = array();
        $sqlQuery = new Query();
        if( $this->key == '' ){
            $results = $sqlQuery->execLit("select i.hkey, i.skey, i.hostname, i.ip, i.ip2, i.ip3, i.ip4,i.ip5, i.ip6, i.virtual, i.production, i.os, i.osver, i.ospatch, i.san, i.cluster, i.owner, i.lastupdate, i.ram, i.uptime, i.swap, diskmon, i.ccmsmon, i.tbsmon, i.sapmaint, i.cruntime, i.javaver, i.javavend, i.javaverfull, i.mailserver, i.adminpass, i.lastbackup, i.itar, i.cronjobs, i.aioact, i.aiomin, i.aiomax, i.procmax, i.appinst, i.app, i.storage, i.comments, i.man_update, i.isr, i.datertu, k.audit, i.support_mail, k.live, i.supvendor, i.sbu, i.sbe, i.priority, i.suphours, i.startnote, i.stopnote, i.hdd, i.asset, i.hwasset, i.product, i.vmtype, i.tier2, i.tier3, i.vencontact, i.venphone, i.esccontact, i.escphone, i.esc2contact, i.esc2phone, i.netname, i.capability, i.caplist, i.domain, i.cidesc, i.billable, i.instid, i.recid, i.appliance, i.decomdate, sk.serial, si.datacenter, si.rack, sk.servername from host_info i, host_key k, sys_info si, sys_key sk where i.hostname='$this->name' and k.hkey = i.hkey and si.skey = i.skey and sk.skey = i.skey ", 0);            
        }
        else{
            // Query based on key - much better, mostly used when just re-syncing
            $results = $sqlQuery->execLit("select i.hkey, i.skey, i.hostname, i.ip, i.ip2, i.ip3, i.ip4,i.ip5, i.ip6, i.virtual, i.production, i.os, i.osver, i.ospatch, i.san, i.cluster, i.owner, i.lastupdate, i.ram, i.uptime, i.swap, diskmon, i.ccmsmon, i.tbsmon, i.sapmaint, i.cruntime, i.javaver, i.javavend, i.javaverfull, i.mailserver, i.adminpass, i.lastbackup, i.itar, i.cronjobs, i.aioact, i.aiomin, i.aiomax, i.procmax, i.appinst, i.app, i.storage, i.comments, i.man_update, i.isr, i.datertu, i.support_mail, k.audit, k.live, i.supvendor, i.sbu, i.sbe, i.priority, i.suphours, i.startnote, i.stopnote, i.hdd, i.asset, i.hwasset, i.product, i.vmtype, i.tier2, i.tier3, i.vencontact, i.venphone, i.esccontact, i.escphone, i.esc2contact, i.esc2phone, i.netname, i.capability, i.caplist, i.domain, i.cidesc, i.billable, i.instid, i.recid, i.appliance, i.decomdate, sk.serial, si.datacenter, si.rack, sk.servername from host_info i, host_key k, sys_info si, sys_key sk where i.hostname like '%$this->name%' and k.hkey = '$this->key' and k.hkey = i.hkey and si.skey = i.skey and sk.skey ", 0);
        }
        if( $sqlQuery->getCount() <= 0 ){ 
            if($verbose != ''){ print "No host of name " . $this->name . " exists <br />\n"; }
            return 0;
        }
        else{
            // In the case of duplicates, we're just going to use the first - but warn if verbose
            if(($sqlQuery->getCount() > 1) && ($verbose != '')){ print "Duplicate hosts with the name " . $this->name . " exist! <br />\n"; }
            $this->active     = $results[0]['live'];
            $this->key        = $results[0]['hkey'];
            $this->cluster    = $results[0]['cluster'];
            $this->ram        = $results[0]['ram'];
            $this->swap       = $results[0]['swap'];
            $this->datacenter = $results[0]['datacenter'];
            $this->group      = $results[0]['owner'];
            $this->ip         = $results[0]['ip'];
            $this->ip2        = $results[0]['ip2'];
            $this->ip3        = $results[0]['ip3'];
            $this->ip4        = $results[0]['ip4'];
            $this->ip5        = $results[0]['ip5'];
            $this->ip6        = $results[0]['ip6'];
            $this->isr        = $results[0]['isr'];
            $this->dateact    = $results[0]['datertu'];
            $this->email      = $results[0]['support_mail']; 
            $this->serial     = $results[0]['serial'];
            $this->audit      = $results[0]['audit'];   
            $this->manual     = $results[0]['man_update']; 
            $this->prod       = $results[0]['production'];
            $this->os         = $results[0]['os'];
            $this->osver      = $results[0]['osver'];
            $this->ospatch    = $results[0]['ospatch'];
            $this->san        = $results[0]['san'];
            $this->uptime     = $results[0]['uptime'];
            $this->diskmon    = $results[0]['diskmon'];
            $this->ccmsmon    = $results[0]['ccmsmon'];
            $this->tbsmon     = $results[0]['tbsmon'];
            $this->sapmaint   = $results[0]['sapmaint'];
            $this->cruntime   = $results[0]['cruntime'];
            $this->javaver    = $results[0]['javaver'];
            $this->javavend   = $results[0]['javavend'];
            $this->javaverfull= $results[0]['javaverfull'];
            $this->mailserver = $results[0]['mailserver'];
            $this->lastbackup = $results[0]['lastbackup'];
            $this->adminpass  = $results[0]['adminpass'];
            $this->itar       = $results[0]['itar'];
            $this->cronjobs   = $results[0]['cronjobs'];
            $this->aioact     = $results[0]['aioact'];
            $this->aiomin     = $results[0]['aiomin'];
            $this->aiomax     = $results[0]['aiomax'];
            $this->procmax    = $results[0]['procmax'];
            $this->appinst    = $results[0]['appinst'];
            $this->app        = $results[0]['app'];
            $this->storage    = $results[0]['storage'];
            $this->virtual    = $results[0]['virtual'];
            $this->skey       = $results[0]['skey'];
            $this->server     = $results[0]['servername'];
            $this->lastupdate = $results[0]['lastupdate'];
            $this->comments   = $results[0]['comments'];
            $this->supvendor  = $results[0]['supvendor'];
            $this->sbu        = $results[0]['sbu'];
            $this->sbe        = $results[0]['sbe'];
            $this->priority   = $results[0]['priority'];
            $this->suphours   = $results[0]['suphours'];
            $this->startnote  = $results[0]['startnote'];
            $this->stopnote   = $results[0]['stopnote'];
            $this->hdd        = $results[0]['hdd'];
            $this->asset      = $results[0]['asset'];
            $this->hwasset    = $results[0]['hwasset'];
            $this->product    = $results[0]['product'];
            $this->vmtype     = $results[0]['vmtype'];
            $this->tier2      = $results[0]['tier2'];
            $this->tier3      = $results[0]['tier3'];
            $this->vencontact = $results[0]['vencontact'];
            $this->venphone   = $results[0]['venphone'];
            $this->esccontact = $results[0]['esccontact'];
            $this->escphone   = $results[0]['escphone'];
            $this->esc2contact= $results[0]['esc2contact'];
            $this->esc2phone  = $results[0]['esc2phone'];
            $this->netname    = $results[0]['netname'];
            $this->capability = $results[0]['capability'];
            $this->caplist    = $results[0]['caplist'];
            $this->domain     = $results[0]['domain'];
            $this->cidesc     = $results[0]['cidesc'];
            $this->billable   = $results[0]['billable'];
            $this->instid     = $results[0]['instid'];
            $this->recid      = $results[0]['recid'];
            $this->appliance  = $results[0]['appliance'];
            $this->decomdate  = $results[0]['decomdate'];
            $this->rack       = $results[0]['rack'];
            
            
            // Convert 'booleans' if the DB returns 0/1
            $this->active   = str_replace("1", "y", $this->active);
            $this->active   = str_replace("0", "n", $this->active);
            $this->audit    = str_replace("1", "y", $this->audit);
            $this->audit    = str_replace("0", "n", $this->audit);
            $this->manual   = str_replace("1", "y", $this->manual);
            $this->manual   = str_replace("0", "n", $this->manual); 
            $this->virtual  = str_replace("0", "n", $this->virtual);
            $this->virtual  = str_replace("1", "y", $this->virtual);
            $this->prod     = str_replace("0", "n", $this->prod);
            $this->prod     = str_replace("1", "y", $this->prod);
            $this->itar     = str_replace("0", "n", $this->itar);
            $this->itar     = str_replace("1", "y", $this->itar);
            $this->billable = str_replace("0", "n", $this->billable);
            $this->billable = str_replace("1", "y", $this->billable);
            $this->appliance= str_replace("0", "n", $this->appliance);
            $this->appliance= str_replace("1", "y", $this->appliance);
            
            // Return the rowcount so we can easily tell if there were dupes - if we care.
            return $sqlQuery->getCount();
        }       
    }
    
    
    public function create(){
        print( "Creation disabled temporarily" );
        return(0);
    }
    public function update(){
        print( "Updating disabled temporarily" );
        return(0);
    }
    
    // Get/Set functions - roughly alphabetical order, grouped get/set
    
    // getActive inherited
    public function setActive($active){
        $active       = substr($active, 0, 1);
        $this->active = fixSQL($active);
        $this->active = str_replace("n", "0", $this->active);
        $this->active = str_replace("y", "1", $this->active);
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');
        $sqlQuery->execLit( "update host_key set live = '$this->active' where hostname='$this->name' and hkey='$this->key' " ); 
        $sqlQuery->execLit( "update host_info set lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );     
        // Re-read the object from the database so they stay in sync
        $this::init();       
        return $this->active;
    }
    
    public function getApp(){
        return $this->app;
    }    
    public function setApp($app){
        $this->app = fixSQL($app);
        global $dbtype;
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');
        $sqlQuery->execLit( "update host_info set app = '$this->app', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->app;
    }
    
    public function getAppinst(){
        return $this->appinst;
    }    
    public function setAppinst($appinst){
        $this->appinst = fixSQL($appinst);
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');
        $sqlQuery->execLit( "update host_info set appinst = '$this->appinst', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->appinst;
    }
    
    public function getAppliance(){
        return $this->appliance;
    }    
    public function setAppliance($appliance){
        // The billable flag basically is used only for CMDB/Cost type reports. 
        // It's only set on things like HMCs and some ESX hosts, BIA, Google Search Appliances, etc.      
        $appliance       = substr($appliance, 0, 1);
        $this->appliance = fixSQL($appliance);
        $this->appliance = str_replace("n", "0", $this->appliance);
        $this->appliance = str_replace("y", "1", $this->appliance);
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');
        $sqlQuery->execLit( "update host_info set appliance = '$this->appliance', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->appliance;
    }
    
    public function getAsset(){
        return $this->asset;
    }    
    public function setAsset($asset){      
        $this->asset = fixSQL($asset);     
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');
        $sqlQuery->execLit( "update host_info set asset = '$this->asset', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->asset;
    }
    
    public function getAudit(){
        return $this->audit;
    }
    public function setAudit($audit){
        $this->audit = fixSQL($audit);        
        $now = date('Y-m-d H:i:s');   
        $sqlQuery = new Query();     
        $sqlQuery->execLit( "update host_key set audit = '$this->audit' where hostname='$this->name' and hkey='$this->key' " ); 
        $sqlQuery->execLit( "update host_info set lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );       
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->audit;
    }   
    
    public function getBillable(){
        return $this->billable;
    }    
    public function setBillable($billable){
        // The billable flag basically is used only for CMDB/Cost type reports. 
        // It's only set on things like HMCs and some ESX hosts      
        $billable       = substr($billable, 0, 1);
        $this->billable = fixSQL($billable);
        $this->billable = str_replace("n", "0", $this->billable);
        $this->billable = str_replace("y", "1", $this->billable);        
        $now = date('Y-m-d H:i:s');   
        $sqlQuery = new Query();     
        $sqlQuery->execLit( "update host_info set billable = '$this->billable', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->billable;
    }
    
    public function getCapability(){
        return $this->capability;
    }   
    public function setCapability($capability){      
        $this->capability = fixSQL($capability);      
        $now = date('Y-m-d H:i:s');   
        $sqlQuery = new Query();     
        $sqlQuery->execLit( "update host_info set capability = '$this->capability', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->capability;
    }
    
    public function getCaplist(){
        return $this->caplist;
    }    
    public function setCaplist($caplist){      
        $this->caplist = fixSQL($caplist);      
        $now = date('Y-m-d H:i:s');   
        $sqlQuery = new Query();     
        $sqlQuery->execLit( "update host_info set caplist = '$this->caplist', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->caplist;
    }
    
    public function getCIDesc(){
        return $this->cidesc;
    }   
    public function setCIDesc($cidesc){
        $this->cidesc = fixSQL($cidesc);
        $now = date('Y-m-d H:i:s');   
        $sqlQuery = new Query();     
        $sqlQuery->execLit( "update host_info set cidesc = '$this->cidesc', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->cidesc;
    }
    
    //getComments inherited
    public function setComments($comments){
        $this->comments = fixSQL($comments);
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');        
        $sqlQuery->execLit( "update host_info set comments = '$this->comments', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init();
        return $this->comments;
    } 
    
    public function getDBs(){
        // This gets all the DBs that say they depend on this server (doesn't find much yet)
        $sqlQuery = new Query();      
        $sqlQuery->execLit( "select i.dkey, i.dbname, k.live, i.owner from db_info i, db_key k where hkey = '$this->key'  and i.dkey = k.dkey" , 0);    
        return $sqlQuery->getCount();
    }
    // No setDBs because this is a dynamic function
    
    public function getDC(){
        return $this->datacenter;
    }
    // No setDC because it's part of the setServer
    
    public function getDecomdate(){
        return $this->decomdate;
    }
    public function setDecomdate($decomdate){
        $this->decomdate = fixSQL($decomdate);
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');        
        $sqlQuery->execLit( "update host_info set decomdate = '$this->decomdate', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init();
        return $this->decomdate;
    }
    
    public function getDomain(){
        return $this->domain;
    }   
    public function setDomain($domain){      
        $this->domain = fixSQL($domain);      
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');        
        $sqlQuery->execLit( "update host_info set domain = '$this->domain', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->domain;
    }
    
    //getEmail is inherited
    public function setEmail($email){
        $this->email = fixSQL($email);
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');        
        $sqlQuery->execLit( "update host_info set support_mail = '$this->email', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->email;
    }
    
    public function getEscContact(){
        return $this->esccontact;
    }    
    public function setEscContact($esccontact){      
        $this->esccontact = fixSQL($esccontact);      
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');        
        $sqlQuery->execLit( "update host_info set esccontact = '$this->esccontact', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->esccontact;
    }
    
    public function getEscPhone(){
        return $this->escphone;
    }   
    public function setEscPhone($escphone){      
        $this->escphone = fixSQL($escphone);       
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');        
        $sqlQuery->execLit( "update host_info set escphone = '$this->escphone', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->escphone;
    }
    
    public function getEsc2Contact(){
        return $this->esc2contact;
    }    
    public function setEsc2Contact($esccontact){      
        $this->esc2contact = fixSQL($esccontact);      
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');        
        $sqlQuery->execLit( "update host_info set esc2contact = '$this->esc2contact', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->esc2contact;
    }
    
    public function getEsc2Phone(){
        return $this->esc2phone;
    }   
    public function setEsc2Phone($escphone){      
        $this->esc2phone = fixSQL($escphone);       
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');        
        $sqlQuery->execLit( "update host_info set esc2phone = '$this->esc2phone', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->esc2phone;
    }
    
    //getGroup inherited
    public function setGroup($owner){
        $this->group = fixSQL($owner);
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');        
        $sqlQuery->execLit( "update host_info set owner = '$this->owner', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );        
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->owner;
    }
    
    public function getHDD(){
        return $this->hdd;
    }   
    public function setHDD($hdd){      
        $this->hdd = fixSQL($hdd);      
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');        
        $sqlQuery->execLit( "update host_info set hdd = '$this->hdd', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->hdd;
    }
    
    public function getHours(){
        return $this->suphours;
    }    
    public function setHours($suphours){      
        $this->suphours = fixSQL($suphours);      
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');        
        $sqlQuery->execLit( "update host_info set suphours = '$this->suphours', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->suphours;
    }
    
    public function getHWAsset(){
        return $this->hwasset;
    }   
    public function setHWAsset($hwasset){      
        $this->hwasset = fixSQL($hwasset);       
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');        
        $sqlQuery->execLit( "update host_info set hwasset = '$this->hwasset', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->hwasset;
    }
    
    public function getInstid(){
        return $this->instid;
    }   
    public function setInstid($instid){
        $this->instid = fixSQL($instid);
        $sqlQuery = new Query();
        $now = date('Y-m-d H:i:s');        
        $sqlQuery->execLit( "update host_info set instid = '$this->instid', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->instid;
    }
    
    public function getIP(){
        return $this->ip;
    }    
    public function setIP($ip){
        $this->ip = fixSQL($ip);
        $now = date('Y-m-d H:i:s');  
        $sqlQuery = new Query();      
        $sqlQuery->execLit( "update host_info set ip = '$this->ip', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->ip;
    }
    
    public function getIP2(){
        return $this->ip2;
    }    
    public function setIP2($ip){
        $this->ip2 = fixSQL($ip);
        $now = date('Y-m-d H:i:s');  
        $sqlQuery = new Query();      
        $sqlQuery->execLit( "update host_info set ip2 = '$this->ip2', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->ip2;
    }
    
    public function getIP3(){
        return $this->ip3;
    }    
    public function setIP3($ip){
        $this->ip3 = fixSQL($ip);
        $now = date('Y-m-d H:i:s');  
        $sqlQuery = new Query();      
        $sqlQuery->execLit( "update host_info set ip3 = '$this->ip3', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->ip3;
    }
    
    public function getIP4(){
        return $this->ip4;
    }    
    public function setIP4($ip){
        $this->ip4 = fixSQL($ip);
        $now = date('Y-m-d H:i:s');  
        $sqlQuery = new Query();      
        $sqlQuery->execLit( "update host_info set ip4 = '$this->ip4', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->ip4;
    }

    public function setIP5($ip){
        $this->ip5 = fixSQL($ip);
        $now = date('Y-m-d H:i:s');  
        $sqlQuery = new Query();      
        $sqlQuery->execLit( "update host_info set ip5 = '$this->ip5', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->ip5;
    }
    
    public function setIP6($ip){
        $this->ip6 = fixSQL($ip);
        $now = date('Y-m-d H:i:s');  
        $sqlQuery = new Query();      
        $sqlQuery->execLit( "update host_info set ip6 = '$this->ip6', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->ip6;
    }
    
    public function getISR(){
        return $this->isr;
    }    
    public function setISR($isr){
        $this->isr = fixSQL($isr);
        $now = date('Y-m-d H:i:s');  
        $sqlQuery = new Query();      
        $sqlQuery->execLit( "update host_info set isr = '$this->isr', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->isr;
    }
    
    public function getITAR(){
        return $this->itar;
    }
    
    public function setITAR($itar){      
        $itar       = substr($itar, 0, 1);
        $this->itar = fixSQL($itar);
        $this->itar = str_replace("n", "0", $this->itar);
        $this->itar = str_replace("y", "1", $this->itar);       
        $now = date('Y-m-d H:i:s');  
        $sqlQuery = new Query();      
        $sqlQuery->execLit( "update host_info set itar = '$this->itar', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->itar;
    }
    
    public function getNetName(){
        return $this->netname;
    }    
    public function setNetName($netname){ 
        //This should really come from the net_info - but put into host_info for quick CMDB stuff     
        $this->netname = fixSQL($netname);      
        $now = date('Y-m-d H:i:s');  
        $sqlQuery = new Query();      
        $sqlQuery->execLit( "update host_info set netname = '$this->netname', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->netname;
    }
    
    public function getOS(){
        return $this->os;
    }    
    public function setOS($os){
        $os = strtoupper($os);
        if( strpos($os, 'AIX') > -1 ){ $os = 'AIX'; }
        if( strpos($os, 'HP' ) > -1 ){ $os = 'HPUX'; }
        if( strpos($os, 'LIN') > -1 ){ $os = 'LINUX'; }
        if( strpos($os, 'WIN') > -1 ){ $os = 'WINDOWS'; }
        if( strpos($os, 'SOL') > -1 ){ $os = 'SOLARIS'; }
        $this->os = fixSQL($os);
        $now = date('Y-m-d H:i:s');  
        $sqlQuery = new Query();      
        $sqlQuery->execLit( "update host_info set os = '$this->os', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->os;
    }
    
    public function getOSVer(){
        return $this->osver;
    }    
    public function setOSVer($osver){
        $this->osver = fixSQL($osver);
        $now = date('Y-m-d H:i:s');  
        $sqlQuery = new Query();      
        $sqlQuery->execLit( "update host_info set osver = '$this->osver', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->osver;
    }
    
    public function getPriority(){
        return $this->priority;
    }    
    public function setPriority($priority){      
        $this->priority = fixSQL($priority);       
        $now = date('Y-m-d H:i:s');  
        $sqlQuery = new Query();      
        $sqlQuery->execLit( "update host_info set priority = '$this->priority', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->priority;
    }
    
    public function getProd(){
        return $this->prod;
    }   
    public function setProd($prod){      
        $prod       = substr($prod, 0, 1);
        $this->prod = fixSQL($prod);
        $this->prod = str_replace("n", "0", $this->prod);
        $this->prod = str_replace("y", "1", $this->prod);        
        $now = date('Y-m-d H:i:s');  
        $sqlQuery = new Query();      
        $sqlQuery->execLit( "update host_info set production = '$this->prod', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->prod;
    }
    
    public function getProduct(){
        //Product is for the 'product description' like Red Hat Enterprise Linux 5, instead of RHEL5.
        return $this->product;
    }    
    public function setProduct($product){      
        $this->product = fixSQL($product);       
        $now = date('Y-m-d H:i:s');  
        $sqlQuery = new Query();      
        $sqlQuery->execLit( "update host_info set product = '$this->product', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->product;
    }
    
    public function getRack(){
        return $this->rack;
    }    
    public function setRack($rack){                
        $this->rack = fixSQL($rack);
        $now = date('Y-m-d H:i:s');
        $sqlQuery = new Query(); 
        $sqlQuery->execLit( "update sys_info set rack = '$this->rack', lastupdate = '$now' where skey ='$this->skey' " );               
        // Re-read the object from the database so they stay in sync
        $this::init();       
        return $this->rack;
    }
    
    public function getRAM(){
        return $this->ram;
    }    
    public function setRAM($ram){
        $this->ram = fixSQL($ram);
        $now = date('Y-m-d H:i:s');
        $sqlQuery = new Query(); 
        $sqlQuery->execLit( "update host_info set ram = '$this->ram', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->ram;
    }
    
    public function getRecid(){
        return $this->recid;
    }    
    public function setRecid($recid){
        $this->recid = fixSQL($recid);
        $now = date('Y-m-d H:i:s');
        $sqlQuery = new Query(); 
        $sqlQuery->execLit( "update host_info set recid = '$this->recid', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->recid;
    }
    
    public function getSBE(){
        return $this->sbe;
    }    
    public function setSBE($sbe){      
        $this->sbe = fixSQL($sbe);       
        $now = date('Y-m-d H:i:s');
        $sqlQuery = new Query(); 
        $sqlQuery->execLit( "update host_info set sbe = '$this->sbe', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->sbe;
    }  
    
    public function getSBU(){
        return $this->sbu;
    }    
    public function setSBU($sbu){      
        $this->sbu = fixSQL($sbu);      
        $now = date('Y-m-d H:i:s');
        $sqlQuery = new Query(); 
        $sqlQuery->execLit( "update host_info set sbu = '$this->sbu', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->sbu;
    }
    
    
    public function getServer(){
        return $this->server;
    }     
    public function setServer($server){              
        $results = array();
        $this->server = fixSQL($server);
        $now = date('Y-m-d H:i:s');
        $sqlQuery = new Query();         
        $results = $sqlQuery->execLit( "select k.skey, k.servername, i.datacenter, serial, k.servername, i.rack from sys_key k, sys_info i where k.servername = '$this->server' and k.skey = i.skey ", 0);
        if($sqlQuery->getCount() > 0){
            $this->skey       = $results[0]['skey'];
            $this->server     = $results[0]['servername'];
            $this->datacenter = $results[0]['datacenter'];
            $this->serial     = $results[0]['serial'];
            $this->rack       = $results[0]['rack'];
        }
        else{ $this->skey = '1'; }        
        $sqlQuery->execLit( "update host_info set lastupdate = '$now', skey = '$this->skey' where hostname='$this->name' and hkey='$this->key' " );  
         
        // Re-read the object from the database so they stay in sync
        $this::init();       
        return $this->server;
    }
    
    public function getSkey(){
        return $this->skey;
    }
    // The setSkey is part of set server, not broken out.
    
    public function getStart(){
        return $this->startnote;
    }   
    public function setStart($startnote){      
        $this->startnote = fixSQL($startnote);      
        $now = date('Y-m-d H:i:s');
        $sqlQuery = new Query(); 
        $sqlQuery->execLit( "update host_info set startnote = '$this->startnote', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->startnote;
    }
    
    public function getStop(){
        return $this->stopnote;
    }    
    public function setStop($stopnote){      
        $this->stopnote = fixSQL($stopnote);       
        $now = date('Y-m-d H:i:s');
        $sqlQuery = new Query(); 
        $sqlQuery->execLit( "update host_info set stopnote = '$this->stopnote', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->stopnote;
    }
    
    public function getSwap(){
        return $this->swap;
    }    
    public function setSwap($swap){
        $this->swap = fixSQL($swap);
        $now = date('Y-m-d H:i:s');
        $sqlQuery = new Query(); 
        $sqlQuery->execLit( "update host_info set swap = '$this->swap', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->swap;
    }
    
    public function getTier2(){
        return $this->tier2;
    }    
    public function setTier2($tier2){      
        $this->tier2 = fixSQL($tier2);      
        $now = date('Y-m-d H:i:s');
        $sqlQuery = new Query(); 
        $sqlQuery->execLit( "update host_info set tier2 = '$this->tier2', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->tier2;
    }
    
    public function getTier3(){
        return $this->tier3;
    }    
    public function setTier3($tier3){      
        $this->tier3 = fixSQL($tier3);      
        $now = date('Y-m-d H:i:s');
        $sqlQuery = new Query(); 
        $sqlQuery->execLit( "update host_info set tier3 = '$this->tier3', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->tier3;
    }
    
    public function getVendor(){
        return $this->supvendor;
    }    
    public function setVendor($supvendor){      
        $this->supvendor = fixSQL($supvendor);       
        $now = date('Y-m-d H:i:s');
        $sqlQuery = new Query(); 
        $sqlQuery->execLit( "update host_info set supvendor = '$this->supvendor', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->supvendor;
    }
    
    public function getVenContact(){
        return $this->vencontact;
    }    
    public function setVenContact($vencontact){      
        $this->vencontact = fixSQL($vencontact);       
        $now = date('Y-m-d H:i:s');
        $sqlQuery = new Query(); 
        $sqlQuery->execLit( "update host_info set vencontact = '$this->vencontact', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->vencontact;
    }
    
    public function getVenPhone(){
        return $this->venphone;
    }    
    public function setVenPhone($venphone){      
        $this->venphone = fixSQL($venphone);      
        $now = date('Y-m-d H:i:s');
        $sqlQuery = new Query(); 
        $sqlQuery->execLit( "update host_info set venphone = '$this->venphone', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->venphone;
    }
    
    public function getVM(){
        return $this->virtual;
    }    
    public function setVM($vm){      
        $vm            = substr($vm, 0, 1);
        $this->virtual = fixSQL($vm);
        $this->virtual = str_replace("n", "0", $this->virtual);
        $this->virtual = str_replace("y", "1", $this->virtual);    
        $now = date('Y-m-d H:i:s');
        $sqlQuery = new Query(); 
        $sqlQuery->execLit( "update host_info set virtual = '$this->virtual', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->virtual;
    }
    
    public function getVMType(){
        return $this->vmtype;
    }    
    public function setVMType($vmtype){      
        $this->vmtype = fixSQL($vmtype);       
        $now = date('Y-m-d H:i:s');
        $sqlQuery = new Query(); 
        $sqlQuery->execLit( "update host_info set vmtype = '$this->vmtype', lastupdate = '$now' where hostname='$this->name' and hkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->vmtype;
    }
    
    
    //Output methods
    public function printTRShort() {
        // Just print the most common ones
        print "<tr><td>Hostname</td><td>"   . $this->name       . "</td></tr>\n";
        print "<tr><td>IP</td><td>"         . $this->ip         . "</td></tr>\n";
        print "<tr><td>Datacenter</td><td>" . $this->datacenter . "</td></tr>\n";
        print "<tr><td>RAM</td><td>"        . $this->ram        . "</td></tr>\n";
        print "<tr><td>Swap</td><td>"       . $this->swap       . "</td></tr>\n";
        print "<tr><td>Live</td><td>"       . $this->active     . "</td></tr>\n";
        print "<tr><td>RTU Date</td><td>"   . $this->dateact    . "</td></tr>\n";
        print "<tr><td>ISR</td><td>"        . $this->isr        . "</td></tr>\n";
        print "<tr><td>Owner</td><td>"      . $this->owner      . "</td></tr>\n";
        print "<tr><td>Prod</td><td>"       . $this->prod       . "</td></tr>\n";
        print "<tr><td>OS</td><td>"         . $this->os         . "</td></tr>\n";
        print "<tr><td>OS Ver</td><td>"     . $this->osver      . "</td></tr>\n";
        print "<tr><td>App</td><td>"        . $this->app        . "</td></tr>\n";
        print "<tr><td>Appinst</td><td>"    . $this->appinst    . "</td></tr>\n";
        print "<tr><td>Contact</td><td>"    . $this->email      . "</td></tr>\n";
        print "<tr><td>Manual</td><td>"     . $this->manual     . "</td></tr>\n";
        print "<tr><td>Comments</td><td>"   . $this->comments   . "</td></tr>\n";
        print "<tr><td>Virtual</td><td>"    . $this->virtual    . "</td></tr>\n";
        print "<tr><td>ITAR</td><td>"       . $this->itar       . "</td></tr>\n";
        print "<tr><td>Updated</td><td>"    . $this->lastupdate . "</td></tr>\n";      
    }
    
    public function printForm($class=''){
        
        $class1 = "<td class='res-view $class'>";
	$class2 = "</td><td class='hidden res-edit'><input type='text' class='res-edit ui-corner-all' name=";
	$class3 = "</td><td class='hidden res-edit'><input type='text' class='res-edit ui-state-disabled ui-corner-all' readonly name=";
	$class4 = "</td><td class='hidden res-edit'><select class='ui-corner-all res-edit' id=";
	$class5 = "<td class='res-view $class serverlink'>";
	$sqlQuery = new Query();
        $results = $sqlQuery->execLit("select skey, serial, servername from sys_key order by servername", 0);
	
	// Just print the most common ones
        print "<tr><td>Hostname</td>$class1"   . $this->name       . "$class3 'name' value='"       . $this->name       . "' /></td></tr>\n";
        
        print "<tr><td>Servername</td>$class5" . $this->server     . "$class4 'server' name='server'><option name='server' value='" . $this->server ."' > " . $this->server . " </option> ";       
        if( $sqlQuery->getCount() > 0 ){ for( $row = 0; $row < $sqlQuery->getCount(); $row++ ){ print "<option name='server' value='" . $results[$row]['servername'] . "' > " . $results[$row]['servername'] . " </option> ";	} }
        print "</select></td></tr>\n" ;
        
        print "<tr><td>IP</td>$class1"         . $this->ip         . "$class2 'ip' value='"         . $this->ip         . "' /></td></tr>\n";
        print "<tr><td>Backup IP</td>$class1"  . $this->ip2        . "$class2 'ip2' value='"        . $this->ip2        . "' /></td></tr>\n";
        print "<tr><td>Mgmt IP</td>$class1"    . $this->ip3        . "$class2 'ip3' value='"        . $this->ip3        . "' /></td></tr>\n";
        print "<tr><td>RConsole IP</td>$class1". $this->ip4        . "$class2 'ip4' value='"        . $this->ip4        . "' /></td></tr>\n";
        print "<tr><td>Rear IP</td>$class1"    . $this->ip5        . "$class2 'ip5' value='"        . $this->ip5        . "' /></td></tr>\n";
        print "<tr><td>Virtual IP</td>$class1" . $this->ip6        . "$class2 'ip6' value='"        . $this->ip6        . "' /></td></tr>\n";
        print "<tr><td>Datacenter</td>$class1" . $this->datacenter . "$class3 'dc' value='"         . $this->datacenter . "' /></td></tr>\n";
        print "<tr><td>Rack</td>$class1"       . $this->rack       . "$class2 'rack' value='"       . $this->rack       . "' /></td></tr>\n";
        print "<tr><td>RAM</td>$class1"        . $this->ram        . "$class2 'ram' value='"        . $this->ram        . "' /></td></tr>\n";
        print "<tr><td>Swap</td>$class1"       . $this->swap       . "$class2 'swap' value='"       . $this->swap       . "' /></td></tr>\n";
        print "<tr><td>Live</td>$class1"       . $this->active     . "$class4 'active' name='active'><option name='active' value='" . $this->active ."' > " . $this->active . " </option> ";       
        if( $this->prod == 'n'){ print "<option name='active' value='y' >y</option> "; }else{ print "<option name='active' value='n' >n</option> "; }	
        print "</select></td></tr>\n";
        
        print "<tr><td>RTU Date</td>$class1"   . $this->dateact    . "$class2 'datertu' value='"    . $this->dateact    . "' /></td></tr>\n";
        print "<tr><td>ISR</td>$class1"        . $this->isr        . "$class2 'isr' value='"        . $this->isr        . "' /></td></tr>\n";
        print "<tr><td>Owner</td>$class1"      . $this->group      . "$class2 'owner' value='"      . $this->group      . "' /></td></tr>\n";
        print "<tr><td>Prod</td>$class1"       . $this->prod       . "$class4 'prod' name='prod'><option name='prod' value='" . $this->prod ."' > " . $this->prod . " </option> ";       
        if( $this->prod == 'n'){ print "<option name='prod' value='y' >y</option> "; }else{ print "<option name='prod' value='n' >n</option> "; }	
        print "</select></td></tr>\n";
        
        print "<tr><td>OS</td>$class1"         . $this->os         . "$class4 'os' name='os'><option name='os' value='LINUX' >LINUX</option> \n<option name='os' value='AIX' >AIX</option> \n<option name='os' value='WINDOWS' >WINDOWS</option> \n<option name='os' value='SOLARIS' >SOLARIS</option> \n<option name='os' value='VMS' >VMS</option> ";
        print "</select></td></tr>\n";
        
        print "<tr><td>OS Ver</td>$class1"     . $this->osver      . "$class2 'osver' value='"      . $this->osver      . "' /></td></tr>\n";
        print "<tr><td>App</td>$class1"        . $this->app        . "$class2 'app' value='"        . $this->app        . "' /></td></tr>\n";
        print "<tr><td>Appinst</td>$class1"    . $this->appinst    . "$class2 'appinst' value='"    . $this->appinst    . "' /></td></tr>\n";
        print "<tr><td>Contact</td>$class1"    . $this->email      . "$class2 'email' value='"      . $this->email      . "' /></td></tr>\n";
        print "<tr><td>Comments</td>$class1"   . $this->comments   . "$class2 'comments' value='"   . $this->comments   . "' /></td></tr>\n";
        print "<tr><td>Virtual</td>$class1"    . $this->virtual    . "$class4 'vm' name='vm'><option name='vm' value='" . $this->virtual ."' > " . $this->virtual . " </option> ";       
        if( $this->virtual == 'n'){ print "<option name='vm' value='y' >y</option> "; }
        else{ print "<option name='vm' value='n' >n</option> "; }	
        print "</select></td></tr>\n";              
        print "<tr><td>ITAR</td>$class5"       . $this->itar       . "$class4 'itar' name='itar'><option name='itar' value='" . $this->itar ."' > " . $this->itar . " </option> ";       
        if( $this->itar == 'n'){ print "<option name='itar' value='y' >y</option> "; }else{ print "<option name='itar' value='n' >n</option> "; }	
        print "</select></td></tr>\n";
        print "<tr><td>Updated</td>$class1"    . $this->lastupdate . "$class2 'lastupdt' value='"   . $this->lastupdate . "' /></td></tr>\n";
        print "<tr><td>Vendor</td>$class1"     . $this->supvendor  . "$class2 'supvendor' value='"  . $this->supvendor  . "' /></td></tr>\n";
        print "<tr><td>SBU</td>$class1"        . $this->sbu        . "$class2 'sbu' value='"        . $this->sbu        . "' /></td></tr>\n";
        print "<tr><td>SBE</td>$class1"        . $this->sbe        . "$class2 'sbe' value='"        . $this->sbe        . "' /></td></tr>\n";
        print "<tr><td>Priority</td>$class1"   . $this->priority   . "$class2 'priority' value='"   . $this->priority   . "' /></td></tr>\n";
        print "<tr><td>Hours</td>$class1"      . $this->suphours   . "$class2 'suphours' value='"   . $this->suphours   . "' /></td></tr>\n";
        print "<tr><td>Startup</td>$class1"    . $this->startnote  . "$class2 'startnote' value='"  . $this->startnote  . "' /></td></tr>\n";
        print "<tr><td>Shutdown</td>$class1"   . $this->stopnote   . "$class2 'stopnote' value='"   . $this->stopnote   . "' /></td></tr>\n";
        print "<tr><td>Disk</td>$class1"       . $this->hdd        . "$class2 'hdd' value='"        . $this->hdd        . "' /></td></tr>\n";
        print "<tr><td>Asset</td>$class1"      . $this->asset      . "$class2 'asset' value='"      . $this->asset      . "' /></td></tr>\n";
        print "<tr><td>HW Asset</td>$class1"   . $this->hwasset    . "$class2 'hwasset' value='"    . $this->hwasset    . "' /></td></tr>\n";
        print "<tr><td>Product</td>$class1"    . $this->product    . "$class2 'product' value='"    . $this->product    . "' /></td></tr>\n";
        print "<tr><td>VM Type</td>$class1"    . $this->vmtype     . "$class2 'vmtype' value='"     . $this->vmtype     . "' /></td></tr>\n";
        print "<tr><td>Tier 2</td>$class1"     . $this->tier2      . "$class2 'tier2' value='"      . $this->tier2      . "' /></td></tr>\n";
        print "<tr><td>Tier 3</td>$class1"     . $this->tier3      . "$class2 'tier3' value='"      . $this->tier3      . "' /></td></tr>\n";
        print "<tr><td>Ven Contact</td>$class1". $this->vencontact . "$class2 'vencontact' value='" . $this->vencontact . "' /></td></tr>\n";
        print "<tr><td>Ven Phone</td>$class1"  . $this->venphone   . "$class2 'venphone' value='"   . $this->venphone   . "' /></td></tr>\n";
        print "<tr><td>Esc Contact</td>$class1". $this->esccontact . "$class2 'esccontact' value='" . $this->esccontact . "' /></td></tr>\n";
        print "<tr><td>Esc Phone</td>$class1"  . $this->escphone   . "$class2 'escphone' value='"   . $this->escphone   . "' /></td></tr>\n";
        print "<tr><td>Esc2 Contact</td>$class1".$this->esc2contact. "$class2 'esc2contact' value='". $this->esc2contact. "' /></td></tr>\n";
        print "<tr><td>Esc2 Phone</td>$class1" . $this->esc2phone  . "$class2 'esc2phone' value='"  . $this->esc2phone  . "' /></td></tr>\n";
        print "<tr><td>Net Name</td>$class1"   . $this->netname    . "$class2 'netname' value='"    . $this->netname    . "' /></td></tr>\n";
        print "<tr><td>Capability</td>$class1" . $this->capability . "$class2 'capability' value='" . $this->capability . "' /></td></tr>\n";
        print "<tr><td>Cap List</td>$class1"   . $this->caplist    . "$class2 'caplist' value='"    . $this->caplist    . "' /></td></tr>\n";
        print "<tr><td>Domain(Win)</td>$class1". $this->domain     . "$class2 'domain' value='"     . $this->domain     . "' /></td></tr>\n";
        print "<tr><td>CI Desc</td>$class1"    . $this->cidesc     . "$class2 'cidesc' value='"     . $this->cidesc     . "' /></td></tr>\n";
        print "<tr><td>In CMDB</td>$class1"    . $this->billable   . "$class4 'billable' name='billable'><option name='billable' value='" . $this->billable ."' > " . $this->billable . " </option> ";       
        if( $this->billable == 'n'){ print "<option name='billable' value='y' >y</option> "; }else{ print "<option name='billable' value='n' >n</option> "; }	
        print "</select></td></tr>\n";
        
        print "<tr><td>Appliance</td>$class1"   . $this->appliance   . "$class4 'appliance' name='appliance'><option name='appliance' value='" . $this->appliance ."' > " . $this->appliance . " </option> ";       
        if( $this->appliance == 'n'){ print "<option name='appliance' value='y' >y</option> "; }else{ print "<option name='appliance' value='n' >n</option> "; }	
        print "</select></td></tr>\n";
        
        print "<tr><td>Inst ID</td>$class1"    . $this->instid     . "$class2 'instid' value='"     . $this->instid     . "' /></td></tr>\n";
        print "<tr><td>Rec ID</td>$class1"     . $this->recid      . "$class2 'recid' value='"      . $this->recid      . "' /></td></tr>\n";
        print "<tr><td>DecomDate</td>$class1"  . $this->decomdate  . "$class2 'decomdate' value='"  . $this->decomdate  . "' /></td></tr>\n";
        print "<tr><td>Manual</td>$class1"     . $this->manual     . "$class4 'manual' name='manual'><option name='manual' value='" . $this->manual ."' > " . $this->manual . " </option> ";       
        if( $this->manual == 'n'){ print "<option name='manual' value='y' >y</option> "; }else{ print "<option name='manual' value='n' >n</option> "; }	
        print "</select></td></tr>\n";
    }
    
    
 }    
 
 
 class Database extends Resource {
   
    //name, key, group, email, dateact, manual, lastupdate, comments, live/active inherited    
    public $cluster;
    public $isr;
    public $hkey;
    public $hostname;
    public $audit;   
    public $rdbms;
    public $prod;
    public $instance;
    public $conn_string;
    public $app;
    public $osuser;
    public $lastupdate;
    public $adminpass;
    public $dbver;
    public $veredition;
    public $verhuman;
    public $lastbackup;
    public $backupsched;
    public $itar;
    public $instid;
    public $recid;
    public $decomdate;
    
    private $sql;

    public function __construct($name) {
        parent::__construct($name);
        $this::init();
    }

    // define methods   
    public function init($verbose=''){
        $results = array();
        $sqlQuery = new Query();
        if( $this->key == '' ){
            $results = $sqlQuery->execLit("select i.dkey, i.hkey, rdbms, production, instance, cluster, conn_string, app, i.dbname, osuser, owner, lastupdate, adminpass, dbver, veredition, verhuman, lastbackup, backupsched, comments, support_mail, man_update, itar, datertu, isr, k.audit, k.live, hk.hostname from db_info i, db_key k, host_key hk where i.dbname='$this->name' and k.dkey = i.dkey and i.hkey = hk.hkey ", 0);            
        }
        else{
            // Query based on key - much better, mostly used when just re-syncing
            $results = $sqlQuery->execLit("select i.dkey, i.hkey, rdbms, production, instance, cluster, conn_string, app, i.dbname, osuser, owner, lastupdate, adminpass, dbver, veredition, verhuman, lastbackup, backupsched, comments, support_mail, man_update, itar, datertu, isr, k.audit, k.live, hk.hostname from db_info i, db_key k, host_key hk where i.dbname like '%$this->name%' and k.dkey = '$this->key' and k.dkey = i.dkey and i.hkey = hk.hkey", 0);
        }
        if( $sqlQuery->getCount() <= 0 ){ 
            if($verbose != ''){ print "No DB of name " . $this->name . " exists <br />\n"; }
            return 0;
        }
        else{
            // In the case of duplicates, we're just going to use the first - but warn if verbose
            if(($sqlQuery->getCount() > 1) && ($verbose != '')){ print "Duplicate hosts with the name " . $this->name . " exist! <br />\n"; }
            $this->active     = $results[0]['live'];                                  
            $this->key        = $results[0]['dkey'];
            $this->lastupdate = $results[0]['lastupdate'];
            $this->dateact    = $results[0]['datertu'];   
            $this->hkey       = $results[0]['hkey'];
            $this->hostname   = $results[0]['hostname'];
            $this->rdbms      = $results[0]['rdbms'];
            $this->prod       = $results[0]['production'];
            $this->cluster    = $results[0]['cluster'];
            $this->instance   = $results[0]['instance'];
            $this->conn_string= $results[0]['conn_string'];
            $this->app        = $results[0]['app'];
            $this->name       = $results[0]['dbname'];
            $this->osuser     = $results[0]['osuser'];
            $this->group      = $results[0]['owner'];
            $this->adminpass  = $results[0]['adminpass'];
            $this->isr        = $results[0]['isr'];
            $this->dbver      = $results[0]['dbver'];
            $this->veredition = $results[0]['veredition'];
            $this->verhuman   = $results[0]['verhuman'];
            $this->lastbackup = $results[0]['lastbackup'];
            $this->backupsched= $results[0]['backupsched'];
            $this->email      = $results[0]['support_mail'];              
            $this->audit      = $results[0]['audit'];   
            $this->manual     = $results[0]['man_update'];
            $this->comments   = $results[0]['comments'];
            $this->itar       = $results[0]['itar'];
            
            // Convert 'booleans' if the DB returns 0/1
            $this->active = str_replace("1", "y", $this->active);
            $this->active = str_replace("0", "n", $this->active);
            $this->audit  = str_replace("1", "y", $this->audit);
            $this->audit  = str_replace("0", "n", $this->audit);
            $this->manual = str_replace("1", "y", $this->manual);
            $this->manual = str_replace("0", "n", $this->manual); 
            $this->prod   = str_replace("1", "y", $this->prod);
            $this->prod   = str_replace("0", "n", $this->prod); 
            $this->itar   = str_replace("1", "y", $this->itar);
            $this->itar   = str_replace("0", "n", $this->itar);
            
            // Return the rowcount so we can easily tell if there were dupes - if we care.
            return $sqlQuery->getCount();
        }
        
    }
    
    public function create($hkey, $rdbms, $instance='', $verbose='', $manual='n', $conn_string='', $cluster='', $app='', $osuser='', $owner='', $adminpass='', $dbver='', $veredition='', $verhuman='', $backupsched='', $comments='', $email='', $lastbackup='', $itar='y', $isr='', $datertu='', $audit='n', $live='y', $prod='n'){
        // Just an alias to update
        return $this::update($hkey, $rdbms,  $instance, $verbose, $manual, $conn_string, $cluster, $app, $osuser, $owner, $adminpass, $dbver, $veredition, $verhuman, $lastbackup, $backupsched, $comments, $email, $itar, $isr, $datertu, $audit, $live, $prod); 
    } 
    
    public function update($hkey, $rdbms, $instance='', $verbose='', $manual='n', $conn_string='', $cluster='', $app='', $osuser='', $owner='', $adminpass='', $dbver='', $veredition='', $verhuman='', $lastbackup='', $backupsched='', $comments='', $email='', $itar='y', $isr='', $datertu='', $audit='n', $live='y', $prod='n') {  
        // Update creates if it doesn't exist, updates if it does
        
        // Massage the 'booleans'. These will eventually become 1/0 true/false etc depending on DB backend
        // But that will happen in the actual database functions, we'll use y/n everywhere else.
        // First we trim the strings in case the user provided yes or no, etc.
        $live  = substr($live, 0, 1);
	$audit = substr($audit, 0, 1); 
	$manual= substr($manual, 0, 1);
	$prod  = substr($prod, 0, 1);
		
        $now = date('Y-m-d H:i:s');
        $this->lastupdate = $now;
        $this->cluster    = fixSQL($cluster);
        $this->owner      = fixSQL($owner);
        $this->isr        = fixSQL($isr);
        $this->datertu    = fixSQL($datertu);
        $this->email      = fixSQL($email);  
        $this->audit      = fixSQL($audit);   
        $this->manual     = fixSQL($manual);
        $this->rdbms      = fixSQL($rdbms);
        $this->active     = fixSQL($live);
        $this->instance   = fixSQL($instance);
        $this->conn_string= fixSQL($conn_string);
        $this->app        = fixSQL($app);
        $this->osuser     = fixSQL($osuser);
        $this->adminpass  = fixSQL($adminpass);
        $this->dbver      = fixSQL($dbver);
        $this->veredition = fixSQL($veredition);
        $this->verhuman   = fixSQL($verhuman);
        $this->lastbackup = fixSQL($lastbackup);
        $this->backupsched= fixSQL($backupsched);
        $this->comments   = fixSQL($comments);
        $this->itar       = fixSQL($itar);
        $this->prod       = fixSQL($prod);
        $this->hkey       = fixSQL($hkey);
 
            
        
        // updateDB automatically sets it to the current date/time
        //$this->key = updateDB( $this->name, $hkey, $rdbms,  $instance, $conn_string, $cluster, $app, $osuser, $owner, $adminpass, $dbver, $veredition, $verhuman, $lastbackup, $backupsched, $comments, $email, $lastbackup, $itar, $isr, $datertu, $audit, $live, $prod, $manual, $verbose);
        return $this->key;
    }
    
    // Methods for the most common data that I need to update on a server - IP, Live, Comments
    // The Resource class has some of the basic gets, but no sets
    public function getKey(){
        return $this->key;
    }
    
    public function getRDBMS(){
        return $this->rdbms;
    }
    
    public function getVer(){
        return $this->dbver;
    }
    
    public function getOSUser(){
        return $this->osuser;
    }
    
    public function getHost(){
        return $this->hostname;
    }
       
    public function setActive($active){
        $this->active = fixSQL($active);
        $now = date('Y-m-d H:i:s');
        $sqlQuery = new Query(); 
        $sqlQuery->execLit( "update db_key set live = '$this->active' where dbname='$this->name' and dkey='$this->key' " ); 
        $sqlQuery->execLit( "update db_info set lastupdate = '$now' where dbname='$this->name' and dkey='$this->key' " );     
        // Re-read the object from the database so they stay in sync
        $this::init();       
        return $this->active;
    }   
    
    public function getAudit(){
        return $this->audit;
    }
    
    public function setAudit($audit){
        $this->audit = fixSQL($audit);
        $now = date('Y-m-d H:i:s');
        $sqlQuery = new Query(); 
        $sqlQuery->execLit( "update db_key set audit = '$this->audit' where dbname='$this->name' and dkey='$this->key' " ); 
        $sqlQuery->execLit( "update db_info set lastupdate = '$now' where dbname='$this->name' and dkey='$this->key' " );       
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->audit;
    }
    
    public function setComments($comments){
        $this->comments = $comments;
        $now = date('Y-m-d H:i:s');
        $sqlQuery = new Query(); 
        $sqlQuery->execLit( "update db_info set comments = '$this->comments', lastupdate = '$now' where dbname='$this->name' and dkey='$this->key' " );      
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->comments;
    }

    public function getOwner(){
        return $this->group;
    }
    
    public function setOwner($owner){
        $this->group = $owner;
        $now = date('Y-m-d H:i:s');
        $sqlQuery = new Query(); 
        $sqlQuery->execLit( "update db_info set owner = '$this->owner', lastupdate = '$now' where dbname='$this->name' and dkey='$this->key' " );        
        // Re-read the object from the database so they stay in sync
        $this::init(); 
        return $this->group;
    }
    
    public function printTRShort() {
        // Just print the most common ones
        print "<tr><td>DB Name</td><td>"    . $this->name       . "</td></tr>\n";
        print "<tr><td>Cluster</td><td>"    . $this->cluster    . "</td></tr>\n";
        print "<tr><td>RDBMS</td><td>"      . $this->rdbms      . "</td></tr>\n";
        print "<tr><td>Version</td><td>"    . $this->dbver      . "</td></tr>\n";
        print "<tr><td>App</td><td>"        . $this->app        . "</td></tr>\n";
        print "<tr><td>OS User</td><td>"    . $this->osuser     . "</td></tr>\n";
        print "<tr><td>Host</td><td>"       . $this->hostname   . "</td></tr>\n";
        print "<tr><td>Live</td><td>"       . $this->active     . "</td></tr>\n";
        print "<tr><td>RTU Date</td><td>"   . $this->datertu    . "</td></tr>\n";
        print "<tr><td>ISR</td><td>"        . $this->isr        . "</td></tr>\n";
        print "<tr><td>Owner</td><td>"      . $this->owner      . "</td></tr>\n";
        print "<tr><td>Prod</td><td>"       . $this->prod       . "</td></tr>\n";      
        print "<tr><td>Contact</td><td>"    . $this->email      . "</td></tr>\n";
        print "<tr><td>Manual</td><td>"     . $this->manual     . "</td></tr>\n";
        print "<tr><td>Comments</td><td>"   . $this->comments   . "</td></tr>\n";
        print "<tr><td>ITAR</td><td>"       . $this->itar       . "</td></tr>\n";
        print "<tr><td>Updated</td><td>"    . $this->lastupdate . "</td></tr>\n";

    }
    
    public function printForm($class=''){
        $class1 = "<td class='res-view'>";
	$class2 = "</td><td class='hidden res-edit'><input type='text' class='res-edit' name=";	
	$class3 = "</td><td class='hidden res-edit'><input type='text' class='res-edit ui-state-disabled ui-corner-all' readonly name=";
	$class4 = "</td><td class='hidden res-edit'><select class='ui-corner-all res-edit' id=";
	$class5 = "<td class='res-view $class hostlink'>";
	
	$sqlQuery = new Query();
        $results = $sqlQuery->execLit("select hkey, hostname from host_key order by hostname", 0);
	
	// Just print the most common ones
        print "<tr><td>DB Name</td>$class1"   . $this->name       . "$class2 'name' value='"      . $this->name       . "' /></td></tr>\n";
        print "<tr><td>Cluster</td>$class1"   . $this->cluster    . "$class2 'ip' value='"        . $this->cluster    . "' /></td></tr>\n";
        print "<tr><td>RDBMS</td>$class5"     . $this->rdbms      . "$class4 'rdbms' name='rdbms'><option name='rdbms' value='" . $this->rdbms ."' > " . $this->rdbms . " </option> ";       
        print "<option name='rdbms' value='ORACLE' >ORACLE</option> \n<option name='rdbms' value='DB2' >DB2</option> \n<option name='rdbms' value='MSSQL' >MSSQL</option> \n<option name='rdbms' value='MAXDB' >MAXDB</option> \n<option name='rdbms' value='MYSQL' >MYSQL</option> \n<option name='rdbms' value='HANA' >HANA</option> \n<option name='rdbms' value='POSTGRESQL' >POSTGRESQL</option> \n<option name='rdbms' value='SYBASE' >SYBASE</option> ";
        print "</select></td></tr>\n";
        
        print "<tr><td>Version</td>$class1"   . $this->dbver      . "$class2 'dbver' value='"     . $this->dbver      . "' /></td></tr>\n";
        print "<tr><td>App</td>$class1"       . $this->app        . "$class2 'app' value='"       . $this->app        . "' /></td></tr>\n";
        print "<tr><td>OS user</td>$class1"   . $this->osuser     . "$class2 'osuser' value='"    . $this->osuser     . "' /></td></tr>\n";
        print "<tr><td>Host</td>$class5"      . $this->hostname   . "$class4 'hostname' name='hostname'><option name='hostname' value='" . $this->hostname ."' > " . $this->hostname . " </option> ";       
        if( $sqlQuery->getCount() > 0 ){ for( $row = 0; $row < $sqlQuery->getCount(); $row++ ){ print "<option name='hostname' value='" . $results[$row]['hostname'] . "' > " . $results[$row]['hostname'] . " </option> "; } }
        print "</select></td></tr>\n" ;   
        
        print "<tr><td>Live</td>$class1"      . $this->active     . "$class4 'active' name='active'><option name='active' value='" . $this->active ."' > " . $this->active . " </option> ";       
        if( $this->prod == 'n'){ print "<option name='active' value='y' >y</option> "; }else{ print "<option name='active' value='n' >n</option> "; }	
        print "</select></td></tr>\n";
        
        print "<tr><td>RTU Date</td>$class1"  . $this->dateact    . "$class2 'datertu' value='"    . $this->dateact    . "' /></td></tr>\n";
        print "<tr><td>ISR</td>$class1"       . $this->isr        . "$class2 'isr' value='"        . $this->isr        . "' /></td></tr>\n";
        print "<tr><td>Owner</td>$class1"     . $this->group      . "$class2 'owner' value='"      . $this->group      . "' /></td></tr>\n";
        print "<tr><td>Prod</td>$class1"      . $this->prod       . "$class4 'prod' name='prod'><option name='prod' value='" . $this->prod ."' > " . $this->prod . " </option> ";       
        if( $this->prod == 'n'){ print "<option name='prod' value='y' >y</option> "; }else{ print "<option name='prod' value='n' >n</option> "; }	
        print "</select></td></tr>\n";
        
        print "<tr><td>Contact</td>$class1"   . $this->email      . "$class2 'email' value='"     . $this->email      . "' /></td></tr>\n";
        print "<tr><td>Comments</td>$class1"  . $this->comments   . "$class2 'comments' value='"  . $this->comments   . "' /></td></tr>\n";
        print "<tr><td>ITAR</td>$class5"      . $this->itar       . "$class4 'itar' name='itar'><option name='itar' value='" . $this->itar ."' > " . $this->itar . " </option> ";       
        if( $this->itar == 'n'){ print "<option name='itar' value='y' >y</option> "; }else{ print "<option name='itar' value='n' >n</option> "; }	
        print "</select></td></tr>\n";
        
        print "<tr><td>Updated</td>$class1"   . $this->lastupdate . "$class2 'lastupdt' value='"  . $this->lastupdate . "' /></td></tr>\n";
        print "<tr><td>DecomDate</td>$class1" . $this->decomdate  . "$class2 'decomdate' value='"  . $this->decomdate  . "' /></td></tr>\n";
        print "<tr><td>Manual</td>$class1"    . $this->manual     . "$class4 'manual' name='manual'><option name='manual' value='" . $this->manual ."' > " . $this->manual . " </option> ";       
        if( $this->manual == 'n'){ print "<option name='manual' value='y' >y</option> "; }else{ print "<option name='manual' value='n' >n</option> "; }	
        print "</select></td></tr>\n";
    }
    

}
 
 ?>
