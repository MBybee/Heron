<?php
 // This is part of the Heron Enterprise Management Suite for OpenEngine.Org
 // This program is the web-based mid-tier for a server and db workflow management app
 // Version 0.1
 // All code and graphics � Copyright 2005-2013 Mike Bybee, OpenEngine.Org
 // All rights reserved.
 // This app is distributed under the BSD simplified license.
 // You may obtain a copy of the License at:
 // http://openengine.org/license.html 
 // Included libraries may be under LGPL or MIT licenses.
 // Libraries and Plugins Copyright their respective owners. See the libraries for their licenses.

 // This piece just holds all the various reports, some of which are HUGE


function getSQL($dbtype, $query, $filter, $filterby, $orderby){
    // Some DB types will be compatible SQL, some won't. Hence if, not switch
    // We will also have to make a more complex version later - since we'll need where and such

    // SQL Statement Storage
    // Not all database types support boolean. We'll do true(y)=1 false(no)=0
    // Hosts are production if any of the DBs on them are - patched for a bit, since no DBs exist now.
    // TODO: this sucks. Completely re-do this.
    $sql_store = array(
	"intAllHostDBInf"      => ' hostname, ip, replace( replace(h.production,0,\'n\') , 1,\'y\') prd, h.app, h.owner, replace( replace(h.itar,0,\'n\') , 1,\'y\') itar, replace( replace(virtual,0,\'n\') , 1,\'y\') vm, h.isr, os, osver, instance, h.appinst, substr(h.lastupdate,1,10) upd, substr(h.datertu,1,10) rtu from host_info h left outer join db_info d on h.hkey = d.hkey ',
        "intShortHostInf"      => ' hostname, ip, replace( replace(virtual,0,\'n\') , 1,\'y\') vm, replace( replace(host_info.production,0,\'n\') , 1,\'y\') prd, host_info.cluster, os, owner, replace( replace(itar,0,\'n\') , 1,\'y\') itar, app from host_info  ',
        "intInstanceInf"       => ' hostname, ip, appinst, owner, app, replace( replace(host_info.production,0,\'n\') , 1,\'y\') prd, replace( replace(virtual,0,\'n\') , 1,\'y\') vm, host_info.cluster, os, replace( replace(itar,0,\'n\') , 1,\'y\') itar, substr(lastupdate,1,10) upd from host_info ',
        "intShortUserInf"      => ' u.connect_string, u.dbname, userid, sysadmin, rdbms from user_info u, db_info d where d.connect_string = u.connect_string',
        "intShortDBInf"        => ' dkey, hkey, cluster, rdbms, dbver, app, dbname, replace( replace(production,0,\'n\') , 1,\'y\') production, owner from db_info',
        "intShortSoxInf"       => ' hostname, connect_string, dbname, username from sox_admin_users',
        "intShortSpaceInf"     => ' dbid, hostname, dbname, cluster, dbsize, logsize, substr(lastupdate,1,10) upd from db_info',
	"intHostforDBInf"      => ' h.hkey, h.hostname, ip, replace( replace(virtual,0,\'n\') , 1,\'y\') virtual, h.cluster, rdbms, dbver, dbname, app, replace( replace(d.production,0,\'n\') , 1,\'y\') prod from host_info h, host_key k, db_info d where h.hkey = d.hkey and k.hkey = d.hkey ',
	"intShortHostforDBInf" => ' d.dkey, h.hostname, rdbms, dbname, app, replace( replace(d.production,0,\'n\') , 1,\'y\') prod from host_info h, host_key k, db_info d where h.hkey = d.hkey and k.hkey = d.hkey ',
        "intShortHostInf2"     => ' hostname, ip,  replace( replace(virtual,0,\'n\') , 1,\'y\') vm, replace( replace(production,0,\'n\') , 1,\'y\') prd, os, substr(osver,1,7) osver, ram, owner, app, replace( replace(itar,0,\'n\') , 1,\'y\') itar, substr(lastupdate,1,10) upd from host_info ',
        "intLongHostInf"       => ' hostname, ip,  replace( replace(virtual,0,\'n\') , 1,\'y\') vm, replace( replace(production,0,\'n\') , 1,\'y\') prd, os, osver, ram, owner, app, replace( replace(itar,0,\'n\') , 1,\'y\') itar, substr(datertu,1,10) rtu, isr, appinst, substr(lastupdate,1,10) upd from host_info ',
        "intLongHostInf2"      => ' hostname, h.hkey, s.skey, h.ip, s.servername, serial, model, datacenter, replace( replace(h.virtual,0,\'n\') , 1,\'y\') vm, replace( replace(h.production,0,\'n\') , 1,\'y\') prd, h.os, h.osver, h.ram, h.owner, app, replace( replace(h.itar,0,\'n\') , 1,\'y\') itar, substr(h.datertu,1,10) rtu, h.isr, appinst, h.cluster, h.lastbackup, h.comments, h.mailserver, h.lastupdate from host_info h, sys_info s, sys_key sk where h.skey = s.skey and sk.skey = s.skey ',
        "intLongServerInf"     => ' i.servername, serial, ip, owner, cpu, cpunum, ram, model, datacenter dc, substr(datertu,1,10) rtu, isr, substr(lastupdate,1,10) upd from sys_info i, sys_key k where i.skey = k.skey ',
        "intAllHostAndDBInf"   => ' hostid, h.hostname, ipaddress, virtual, h.cluster, os, ramgb, sanattached, osinfo, rdbms, dbver, dbname, app, production from host_info h, db_info d where h.hostname = d.hostname',
        "intIPInf"             => ' ipname, oct1, oct2, oct3, oct4 from net_info ',
        "intHostLogInf"        => ' select hostname, logruns from host_info ', 
        "intAllUserInf"        => ' u.dbname, u.connect_string, userid, username, ntlogin, ntgroup, default_user, sysadmin, create_date, rdbms, sox from user_info u, db_info d where d.connect_string = u.connect_string',
        "intAllDBInf"        => ' dbid, hostname, cluster, rdbms, app, appowner, dbver, dbver_edition, dbinstance, dbname, dbsize, logsize, replace( replace(production,0,\'n\') , 1,\'y\') production, lastupdate, backupfrequency from db_info',
        "intOraOnly"         => 'Select hostname, cluster, rdbms, dbver, dbinstance, app, production, appowner from db_info where rdbms like \'%ORACLE%\'',
        "intMSSQLOnly"       => 'Select hostname, cluster, rdbms, dbver, dbname, app, production, appowner from db_info where rdbms like \'%SQL%\'',
        "intMSSQLOnlySec"    => 'Select hostname, cluster, rdbms, dbver, dbname, app, production, appowner, convert(varchar(max), DecryptByKey(adminpass)), convert(varchar(max), DecryptByKey(comments)) from db_info where rdbms like \'%SQL%\'',
        "intOraOnlySec"      => 'Select hostname, cluster, rdbms, dbver, instance, app, production, appowner, convert(varchar(max), DecryptByKey(adminpass)), convert(varchar(max), DecryptByKey(comments)) from db_info where rdbms like \'%ORACLE%\'',
        "intBasicDBInfSec"   => 'Select hostname, cluster, rdbms, dbver, app, production, appowner, convert(varchar(max), DecryptByKey(adminpass)), convert(varchar(max), DecryptByKey(comments)) from db_info',
        "intHostAndDBInfSec" => 'Select h.hostname, ipaddress, virtual, h.cluster, rdbms, dbver, app, production, convert(varchar(max), DecryptByKey(adminpass)), convert(varchar(max), DecryptByKey(comments))  from host_info h, db_info d where h.hostname = d.hostname',
        "intUsersInf"        => 'Select connect_string, dbname, userid, sysadmin from user_info order by connect_string',
        "intHostOnly"        => 'select hostname from host_info',
        "intDBOnly"          => 'select distinct(rdbms) from db_info',
        "intConnOnly"        => 'select distinct(connect_string) from db_info',
        "intMSSQLConnOnly"   => 'select distinct(connect_string) from db_info where rdbms = \'MSSQL\'',
        "intOraConnOnly"     => 'select distinct(connect_string) from db_info where rdbms = \'ORACLE\' and dbinstance not like \'+ASM%\'',
        "intChangeInf"       => 'select ckey, skey, gkey, status, mod_rec, add_rec, del_rec, chstring, retval from changes order by ckey', 
        "intChangeNext"      => 'select ckey, status, loc, chstring from changes c, gui_key g where c.mod_rec <= g.mod_rec and c.add_rec <= g.add_rec and c.del_rec <= g.del_rec and c.status = \'new\' order by ckey',
        "intChangeActive"    => 'update changes set status = \'active\'',
        "intChangeComplete"  => 'update changes set status = \'complete\'',
	"intMSSQLGetConnStr" => 'select connect_string from db_info where rdbms = \'MSSQL\' group by connect_string, rdbms order by connect_string',
    );

    if(($dbtype == "sqlite") || ($dbtype == "mysql")){
	switch ($query){
	    case "srv":
	        if( $filterby == "" ){ $filterby = 'production'; }elseif( $filterby == "host" ){ $filterby = 'hostname'; }
	        if( $orderby == "" ){ $orderby = 'order by hostname'; }
		return( 'select h.hostname, h.owner, s.datacenter, h.os from host_info h, sys_info s where ' . $filterby . ' like \'' . $filter . '\'  and s.skey = h.skey ' . $orderby );
		break;
	    case "hostreport3":
		if( $filterby == "" ){ $filterby = 'hostname'; }elseif( $filterby == "host" ){ $filterby = 'hostname'; }
		if( $orderby != "" ){ $orderby = ' order by ' . $orderby . ' '; }
		return('select ' . $sql_store['intShortHostInf2'] . ' where ' . $filterby . ' like \'' . $filter .'\' ' . $orderby );
		break;
	    case "hostreport2":
		//return('select hostname, ip, replace( replace(virtual,0,\'n\') , 1,\'y\') virtual, cluster, os from host_info where hostname like \'' . $filter . '\' ' );
		if( $filterby == "" ){ $filterby = 'hostname'; }elseif( $filterby == "host" ){ $filterby = 'hostname'; }
		if( $orderby != "" ){ $orderby = ' order by ' . $orderby . ' '; }    
		return( 'select ' . $sql_store['intShortHostInf'] . ' where ' . $filterby . ' like \'' . $filter .'\' ' . $orderby );
		break;
	    case "hostreport1":
		if( $filterby == "" ){ $filterby = 'hostname'; }elseif( $filterby == "host" ){ $filterby = 'hostname'; }
		if( $orderby != "" ){ $orderby = ' order by ' . $orderby . ' '; }
		return('select ' . $sql_store['intLongHostInf'] . ' where ' . $filterby . ' like \'' . $filter .'\' ' . $orderby );
		break;
            case "syslong":
		if( $filterby == "" ){ $filterby = 'i.servername'; }elseif( $filterby == "server" ){ $filterby = 'hostname'; }
		if( $orderby != "" ){ $orderby = ' order by ' . $orderby . ' '; }
		return('select ' . $sql_store['intLongServerInf'] . ' and ' . $filterby . ' like \'' . $filter .'\' ' . $orderby );
		break;
            case "data":
                //Same as hostreport1 for the purposes of this
		if( $filterby == "" ){ $filterby = 'hostname'; }elseif( $filterby == "host" ){ $filterby = 'hostname'; }
		if( $orderby != "" ){ $orderby = ' order by ' . $orderby . ' '; }
		return('select ' . $sql_store['intLongHostInf2'] . ' and ' . $filterby . ' like \'' . $filter .'\' ' . $orderby );
		break;
	    case "instances":
		if( $filterby == "" ){ $filterby = 'hostname'; }elseif( $filterby == "host" ){ $filterby = 'hostname'; }
		if( $orderby != "" ){ $orderby = ' order by ' . $orderby . ' '; }
		else{ $orderby = ' order by owner, appinst '; }
		return('select ' . $sql_store['intInstanceInf'] . ' where ' . $filterby . ' like \'' . $filter .'\' ' . $orderby );
		break;
            case "network":
		if( $filterby == "" ){ $filterby = 'ipname'; }elseif( $filterby == "ip" ){ $filterby = 'ipstart'; }
		if( $orderby != "" ){ $orderby = ' order by ' . $orderby . ' '; }
		else{ $orderby = ' order by ipname, oct1, oct2, oct3, oct4 '; }
		return('select ' . $sql_store['intIPInf'] . ' where ' . $filterby . ' like \'' . $filter .'\' ' . $orderby );
		break;
	    case "db":
	        if( $filterby == "" ){ $filterby = 'db_info.production'; }elseif( $filterby == "db" ){ $filterby = 'dbname'; }
	        elseif( $filterby == 'production'){$filterby = 'db_info.production'; }
		return( 'select dbname, db_info.owner, datacenter from db_info, host_info, sys_info where ' . $filterby . ' like \'' . $filter . '\' and db_info.hkey = host_info.hkey and sys_info.skey = host_info.skey' . $orderby );                                        
		break;
	    case "dbfull":
		if( $filterby == "" ){ $filterby = 'dbname'; }
	        return( 'select ' . $sql_store['intAllDBInf'] . ' where ' . $filterby . ' like \'' . $filter .'\' ' );
	        break;
	    case "dbshort":
		if( $filterby == "" ){ $filterby = 'dbname'; }
	        return( 'select ' . $sql_store['intShortDBInf'] . ' where ' . $filterby . ' like \'' . $filter .'\' ' );
		break;
	    case "dbhost":
		if( $filterby == "" ){ $filterby = 'live'; }
		return( 'select ' . $sql_store['intHostforDBInf'] . ' and ' . $filterby . ' like \'' . $filter .'\' ' . $orderby );
		break;
	    case "countallSrv":
		if( $filterby == "" ){ $filterby = 'production'; }
		return( 'select count(*) fullcount from host_info where ' . $filterby . ' like \'' . $filter . '\' ');
		break;
            case "countallDB":
		if( $filterby == "" ){ $filterby = 'production'; }
		return( 'select count(*) fullcount from db_info where ' . $filterby . ' like \'' . $filter . '\' ');
		break;
	    case "alldbhost":
		//return( "select \"Running $query with $filterby, $filter\"" );
		// This one is used largely for the search box
		// If there is no filter - we count the results, then try other likely fields
		if( $filterby == "" ){
		    $results = array(); 
		    $filterby = 'hostname'; 
		    $sql = 'select ' . $sql_store['intAllHostDBInf'] . ' where ' . $filterby . ' like \'' . $filter .'\' ';
		    queryDB($dbtype, $results, $sql, '5' );		    
		    $rowcount = count($results);
		    if( $rowcount > 0 ){
			return( $sql );
		    }
		    else{
			// Try another likely field. Just returning out.
			$filterby = 'ip'; 
			$sql = 'select ' . $sql_store['intAllHostDBInf'] . ' where ' . $filterby . ' like \'' . $filter .'\' ';
			queryDB($dbtype, $results, $sql, '5' );
			$rowcount = count($results);
			if( $rowcount > 0 ){
			    return( $sql );
			}

			$filterby = 'os'; 
			$sql = 'select ' . $sql_store['intAllHostDBInf'] . ' where ' . $filterby . ' like \'' . $filter .'\' ';
			queryDB($dbtype, $results, $sql, '5' );
			$rowcount = count($results);
			if( $rowcount > 0 ){
			    return( $sql );
			}
			
			$filterby = 'osver'; 
			$sql = 'select ' . $sql_store['intAllHostDBInf'] . ' where ' . $filterby . ' like \'' . $filter .'\' ';
			queryDB($dbtype, $results, $sql, '5' );
			$rowcount = count($results);
			if( $rowcount > 0 ){
			    return( $sql );
			}

			$filterby = 'h.owner'; 
			$sql = 'select ' . $sql_store['intAllHostDBInf'] . ' where ' . $filterby . ' like \'' . $filter .'\' ';
			queryDB($dbtype, $results, $sql, '5' );
			$rowcount = count($results);
			if( $rowcount > 0 ){
			    return( $sql );
			}
			
			$filterby = 'h.comments'; 
			$sql = 'select ' . $sql_store['intAllHostDBInf'] . ' where ' . $filterby . ' like \'' . $filter .'\' ';
			queryDB($dbtype, $results, $sql, '5' );
			$rowcount = count($results);
			if( $rowcount > 0 ){
			    return( $sql );
			}
			
			$filterby = 'h.appinst'; 
			$sql = 'select ' . $sql_store['intAllHostDBInf'] . ' where ' . $filterby . ' like \'' . $filter .'\' ';
			queryDB($dbtype, $results, $sql, '5' );
			$rowcount = count($results);
			if( $rowcount > 0 ){
			    return( $sql );
			}
			
			$filterby = 'h.app'; 
			$sql = 'select ' . $sql_store['intAllHostDBInf'] . ' where ' . $filterby . ' like \'' . $filter .'\' ';
			queryDB($dbtype, $results, $sql, '5' );
			$rowcount = count($results);
			if( $rowcount > 0 ){
			    return( $sql );
			}
			
			$filterby = 'virtual'; 
			$sql = 'select ' . $sql_store['intAllHostDBInf'] . ' where ' . $filterby . ' = \'1\' ';
			queryDB($dbtype, $results, $sql, '5' );
			$rowcount = count($results);
			if( $rowcount > 0 ){
			    return( $sql );
			}

			
			return( "select \"Going fishing for $query with $filterby, $filter\"" );
		    }
		}
		elseif( $filterby == "host" ){
		    $filterby = 'hostname'; 
		    return( 'select ' . $sql_store['intAllHostDBInf'] . ' where ' . $filterby . ' like \'' . $filter .'\' ' . $orderby );
		}
		elseif( $filterby == "db" ){
		    $filterby = 'dbname'; 
		    //print( "<p>Filter = $filter, filterby = $filterby</p>\n" );
		    return( 'select ' . $sql_store['intShortHostforDBInf'] . ' where ' . $filterby . ' like \'' . $filter .'\' ' . $orderby );
		}
		elseif( $filterby == "owner" ){
		    $filterby = 'host_info.owner'; 
		    $sql = 'select ' . $sql_store['intAllHostDBInf'] . ' where ' . $filterby . ' like \'' . $filter .'\' ';
		    return( $sql );  
		}
		elseif( $filterby == "comment" ){
		    $filterby = 'host_info.comments'; 
		    $sql = 'select ' . $sql_store['intAllHostDBInf'] . ' where ' . $filterby . ' like \'' . $filter .'\' ';
		    return( $sql );  
		}
                else{ return( "select \"No results for $query\"" ); }		
		break;
            case "project":
	        if( $filterby == "" ){ $filterby = 'wip'; }
		return( 'select k.pname, k.status, i.pdesc, i.startdate, i.enddate, i.customer, i.custteam, i.pm from proj_key k, proj_info i where ' . $filterby . ' like \'' . $filter . '\'  and k.pkey = i.pkey ' . $orderby );
		break;
	    case "requiredfor":
	        if( $filterby == "" ){ $filterby = 'resources'; }
		return( 'select k.pname isr, i.startdate, i.enddate, k.status from proj_key k, proj_info i, res_info r where ' . $filterby . ' like \'' . $filter . '\'  and k.pkey = i.pkey group by i.pkey ' . $orderby );
		break;
	    case "resource":
	        if( $filterby == "" ){ $filterby = 'k.rkey'; }
		return( 'select k.rkey, k.resname, k.active, i.rdesc, i.team, i.dept, i.billing, i.mins, i.primeteam, i.email, i.contact1, i.contact2, i.location, i.citizen, i.dutyshift, i.projects, i.specialities, i.allocation, i.comments, k.restype from res_info i, res_key k where ' . $filterby . ' like \'' . $filter . '\'  and i.rkey = k.rkey ' . $orderby );
		break;
            case "userdata":
	        if( $filterby == "" ){ $filterby = 'k.rkey'; }
		return( 'select k.rkey, k.resname, k.active, i.rdesc, i.team, i.dept, i.billing, i.mins, i.primeteam, i.email, i.contact1, i.contact2, i.location, i.citizen, i.dutyshift, i.projects, i.specialities, i.allocation, i.comments, k.restype from res_info i, res_key k where ' . $filterby . ' like \'' . $filter . '\'  and i.rkey = k.rkey ' . $orderby );
		break;
	    case "hostdata":
                //Same as hostreport1 for the purposes of this
		if($filterby == 'host'){ $filterby = 'hostname'; print( "Got Host to filter"); }
		elseif($filterby == ''){ $filterby = 'h.hkey'; }
		if( $orderby != "" ){ $orderby = ' order by ' . $orderby . ' '; }
		return('select ' . $sql_store['intLongHostInf2'] . ' and ' . $filterby . ' like \'' . $filter .'\' ' . $orderby );
		break;
	    case "countallPM":
		if( $filterby == "" ){ $filterby = 'status'; }
		return( 'select count(*) fullcount from proj_key where ' . $filterby . ' like \'' . $filter . '\' ');
		break;	
	    case "countallRes":
		if( $filterby == "" ){ $filterby = 'active'; }
		return( 'select count(*) fullcount from res_key where ' . $filterby . ' like \'' . $filter . '\' ');
		break;	
	    case "events":
		if( $filterby == "" ){ $filterby = 'category'; }
		return( 'select k.ename, shortinf, longinf, category, evtdate, priority from event_key k, event_info i where ' . $filterby . ' like \'' . $filter . '\' and k.ekey = i.ekey order by evtdate desc ');
		break;	
            case "hostlogs":
                if( $filterby == "" ){ $filterby = 'hostname'; }
                $sql = 'select ' . $sql_store['intHostLogInf'] . ' where ' . $filterby . ' like \'' . $filter .'\' ';
		return( $sql );
		break;
            case "hostlogsfailed":
                if( $filterby == "" ){ $filterby = 'hostname'; }
                $sql = 'select ' . $sql_store['intHostLogInf'] . ' where ' . $filterby . ' like \'' . $filter . '\' and logruns like \'%failed%\' ';
		return( $sql );  
		break;
	    case "cmdbreport":
	       $sql = 'select concat(h.hostname, \'.honeywell.com\') fqhn, replace( replace(hk.live,0,\'in build\'), 1,\'deployed\') status, supvendor, concat(\'HON \', h.owner) sbg, sbu, sbe, priority, suphours, floor, room, rack, datacenter, cpunum, h.ram/1024 ram, hdd disk, serial, h.asset, hwasset, manuf, product, model, replace( replace(virtual,0,\'n\') , 1,\'y\') virtual, vmtype, h.ip ip, os, osver, ospatch, h.datertu, startnote, stopnote, h.comments comments, tier2, tier3, vencontact, venphone, esccontact, escphone, esc2contact, esc2phone, netname, h.isr projnum, capability, caplist, app role, hk.hostname hostname, domain, replace( replace(h.production,0,\'n\') , 1,\'y\') production, \'\' alias, replace( replace(h.itar,0,\'n\') , 1,\'y\') itar from host_info h, host_key hk, sys_key s, sys_info k where h.skey=s.skey and s.skey = k.skey and hk.hkey = h.hkey and billable = 1 ';
	       return( $sql );
	       break;	       
	    case "cmdbextract":
	       $sql = 'select h.instid, h.recid, h.fqhn, supvendor, concat(\'HON \', h.owner) sbg, sbu, sbe, priority, suphours, state, country, city, address, ucase(room), floor, region, k.datacenter, h.hostname, cpunum, h.ram/1024 ram, hdd disk, serial, \'\' supplier, h.asset hwasset, manuf, model, h.ip, h.ip2 bkpip, h.ip3 mgtip, h.ip4 rconip, h.ip5 rwdip, h.ip6 vip, os, osver, tier2, tier3, vencontact, venphone, \'\' vencell, esccontact, escphone, \'\' esccell, esc2contact, esc2phone, \'\' esc2cell, h.datertu availdate, startnote, stopnote, replace( replace(hk.live,0,\'in build\'), 1,\'deployed\') status, h.comments comment, capability, caplist, replace( replace(h.production,0,\'DEV\') , 1,\'PROD\') production, app role, h.isr project, netname, ospatch, rack, replace( replace(virtual,0,\'no\') , 1,\'yes\') virtual, vmtype, cidesc from host_info h, host_key hk, sys_key s, sys_info k, dc_info d where h.skey=s.skey and s.skey = k.skey and hk.hkey = h.hkey and k.datacenter = d.datacenter and billable = 1 ';
	       //print( $sql );
	       return( $sql );
	       break;
	    case "appupdate":
	       //TODO Finish
	       $sql = 'select h.fqhn, ';
	       return( $sql );
	       break;
	    case "cmdbextract11-12":
	       $sql = ' select * from cmdbextract_2012_11 ';
	       return( $sql );
	       break;	    
	    case "cmdbreport11-12":
	       $sql = ' select * from cmdbreport_2012_11 ';
	       return( $sql );
	       break;  	    
	    case "fujinv":
	       $sql = 'select h.asset, hwasset venasset, serial, \'\' category, os, manuf, model, product, \'\' install_date, h.datertu, k.datacenter, address, city, state, h.hostname, \'\' host_install_date, h.datertu host_rtu, replace( replace(hk.live,0,\'in build\'), 1,\'deployed\') status, h.isr project_id, \'\' service_charge_id, \'\' service_charge_type, \'\' subcategory, \'\' service_desc, \'\' qty, \'\' billing_date, \'\' amount, \'\' note from host_info h, host_key hk, sys_key s, sys_info k, dc_info d where h.skey=s.skey and s.skey = k.skey and hk.hkey = h.hkey and k.datacenter = d.datacenter and billable = 1' ;
	       return( $sql );
	       break;
	    case "demodata":
	       $sql = 'select \'Test Data\' test, \'Test2 Data\' test2, \'Test3 Data\' test3, \'Test4 Data\' test4, \'Test5 Data\' test5 ';
	       return( $sql ); 
	    case "demodata2":
	       $sql = 'select \'Data\' test, \'Test2 Data\' test2, \'Test3 Data\' test3 ';
	       return( $sql ); 
	    case "demodata3":
	       $sql = 'select \'More Test Data\' test, \'Test2 Data\' test2, \'Test3 Data\' test3, \'Test4 Data\' test4, \'Test5 Data\' test5, \'Test6 Data\' test6 ';
	       return( $sql ); 
	    default:
		return( "select \"No results for $query\"" );
		break;
	}
    }
}


?>


