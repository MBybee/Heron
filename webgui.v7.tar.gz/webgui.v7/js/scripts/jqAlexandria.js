// This is part of the Heron Enterprise Management Suite for OpenEngine.Org
// This program is the web-based mid-tier for a server and db workflow management app
// Version 0.1
// All code and graphics © Copyright 2005-2013 Mike Bybee, OpenEngine.Org
// All rights reserved.
// This app is distributed under the BSD simplified license.
// You may obtain a copy of the License at:
// http://openengine.org/license.html 
// Included libraries may be under LGPL or MIT licenses.
// Libraries and Plugins Copyright their respective owners. See the libraries for their licenses.
$(function(){
  mainReports = ["demodata","demodata2","demodata3"];
  currMainRep = mainReports[0];
  subReports  = ["demodata2","demodata3","demodata"];
  currSubRep  = subReports[0];
  currHostKey = 1;
  currDBKey   = 1;
  loggedIn    = false;
  $('.navarea').pageslide({href:'#nav',direction:'right',modal:false});
  //Transparent seems to have to be added here - if added in static content, it gets weird
  $('.navicon').addClass('transparent');
  $('.navicon').hover(function(){$(this).removeClass('transparent');},function(){$(this).addClass('transparent');});
  $('.navicon').click(function(){$(this).removeClass('transparent');});
  $('#rssicon').click(function(){$('#rssfeed').toggle('hidden');});
  $('#rssfeed').toggle('hidden');
  $('#searchicon').click(function(){$('#searchbox').toggle('hidden');});
  $('#searchbox').toggle('hidden');
  $('#login-button').click(function(){ login(); });
  $('#add-button').hide();
  $('#remove-button').hide();
  resetDialogs();
  initialLoad();
  $('#main-right').click(function(){ mainReportSet('right'); });
  $('#main-left').click(function(){ mainReportSet('left'); });
  $('#sub-right').click(function(){ subReportSet('right'); });
  $('#sub-left').click(function(){ subReportSet('left'); });
  
  // Menus 
  $('#reports').click(function(){ reportLoad(); });
  $('#db').click(function(){ dbLoad(); });
  $('#host').click(function(){ hostLoad(); });
  $('#tool').click(function(){ appLoad(); });
  $('#pmo').click(function(){ pmoLoad(); });
  
  // Functions
  function initialLoad(){
    jump = $.getUrlVar('jump');
    switch (jump){
      case "db":
        dbLoad();
        break;
      case "host":
        hostLoad();
        break;
      case "app":
        appLoad();
        break;
      case "pmo":
        pmoLoad();
        break;
      default:
        reportLoad();
        break;
    } 
  }
  
  function mainReportSet(direction){
    switch (direction){
      case "left":
        if( currMainRep == mainReports[0] ){ currMainRep = mainReports[mainReports.length-1]; }
        else{ i = mainReports.indexOf(currMainRep); currMainRep = mainReports[i-1]; }
        break;
      case "right":  
        if( currMainRep == mainReports[mainReports.length-1] ){ currMainRep = mainReports[0]; }
        else{ i = mainReports.indexOf(currMainRep); currMainRep = mainReports[i+1]; }
        break;
      default:
        alert( "Invalid direction: " + direction );        
    }
    switch (currMainRep){
      case "hostkey":
        if(direction == "left"){ currHostKey--; }
        else{ currHostKey++; }
        $('#main-report').load('librarian.php',{objtype:'detail',objname:currMainRep,filter:currDBKey,edit:'n',mincols:'2'},function(){$('.footable').footable(); bindRes(); currHostKey=$('#reseditbutton').attr('alt'); });
        break;
      case "dbkey":
        if(direction == "left"){ currDBKey--; }
        else{ currDBKey++; }
        $('#main-report').load('librarian.php',{objtype:'detail',objname:currMainRep,filter:currDBKey,edit:'n',mincols:'2'},function(){$('.footable').footable(); bindRes(); currDBKey=$('#reseditbutton').attr('alt'); });
        break;
      default:
        $('#main-report').load('librarian.php',{objtype:'gentable',objname:currMainRep,edit:'n',mincols:'2'},function(){$('.footable').footable();});      
    }   
  }

  function subReportSet(direction){
    switch (direction){
      case "left":
        if( currSubRep == subReports[0] ){ currSubRep = subReports[subReports.length-1]; }
        else{ i = subReports.indexOf(currSubRep); currSubRep = subReports[i-1]; }
        break;
      case "right":  
        if( currSubRep == subReports[subReports.length-1] ){ currSubRep = subReports[0]; }
        else{ i = subReports.indexOf(currSubRep); currSubRep = subReports[i+1]; }
        break;
      default:
        alert( "Invalid direction: " + direction );        
    } 
    $('#sub-report').load('librarian.php',{objtype:'gentable',objname:currSubRep,edit:'n',mincols:'1'},function(){$('.footable').footable();}); 
  }
  
  function reportLoad(){
    // Set the main reports to whatever reports are useful
    mainReports = ["hostreport1","db","demodata","demodata2","demodata3" ];
    currMainRep = mainReports[0];
    $('#sub').hide();    
    insSearch('report');
    $('#main-report').load('librarian.php',{objtype:'gentable',objname:currMainRep,edit:'n',mincols:'2'},function(){$('.footable').footable();});
    $('#add-button').attr('title','Add Report (WIP)');
    $('#add-button').off();
    $('#add-button').click(function(){ add('report'); });
  }
  
  function dbLoad(){
    // Set the main reports to whatever reports are useful
    mainReports = ["dbkey","dbkey","dbkey"];
    currMainRep = mainReports[0];
    subReports  = ["demodata2","demodata3","demodata"];
    currSubRep  = subReports[0];
    $('#sub').show();
    insSearch('db');
    $('#main-report').load('librarian.php',{objtype:'detail',objname:currMainRep,filter:currDBKey,edit:'n',mincols:'2'},function(){$('.footable').footable(); bindRes(); });
    $('#sub-report').load('librarian.php',{objtype:'gentable',objname:currSubRep,edit:'n',mincols:'1'},function(){$('.footable').footable();}); 
    $('#add-button').attr('title','Add DB');
    $('#add-button').off();
    $('#add-button').click(function(){ add('db'); });
  }
  
  function hostLoad(){
    // Set the main reports to whatever reports are useful
    mainReports = ["hostkey","hostkey","hostkey"];
    currMainRep = mainReports[0];
    $('#sub').hide();
    insSearch('host');
    $('#main-report').load('librarian.php',{objtype:'detail',objname:currMainRep,filter:currHostKey,edit:'n',mincols:'2'},function(){$('.footable').footable(); bindRes(); });
    $('#add-button').attr('title','Add Host');
    $('#add-button').off();
    $('#add-button').click(function(){ add('host'); });
  }
  
  function appLoad(){
    // Set the main reports to whatever reports are useful
    mainReports = ["demodata","demodata2","demodata3"];
    currMainRep = mainReports[0];
    $('#sub').hide();
    insSearch('app');
    $('#main-report').load('librarian.php',{objtype:'gentable',objname:currMainRep,edit:'n',mincols:'2'},function(){$('.footable').footable();});
    $('#add-button').hide();
    $('#remove-button').hide();
  }
  
  function pmoLoad(){
    // Set the main reports to whatever reports are useful
    mainReports = ["demodata","demodata2","demodata3"];
    currMainRep = mainReports[0];
    $('#sub').hide();
    $('#main-report').load('librarian.php',{objtype:'gentable',objname:currMainRep,edit:'n',mincols:'2'},function(){$('.footable').footable();});
    $('#add-button').hide();
    $('#remove-button').hide();
  }
  
  function login(){
    //showMessage("Login Form not implemented yet");
    $('#login-button').attr('src','images/unlocked_icon.png');
    $('#login-button').attr('title','Click to Logout');
    $('#login-button').off();
    $('#login-button').click(function(){ logout(); });
    $('.secure').show();
    loggedIn = true;
  }
  
  function logout(){
    $('#login-button').attr('src','images/locked_icon.png');
    $('#login-button').attr('title','Click to Login');
    $('#login-button').off();
    $('#login-button').click(function(){ login(); });
    $('.secure').hide();
    loggedIn = false;
  }
  
  function insSearch(mode){
    switch (mode){
      case "db":
        $('#searchbox').empty();
        $('#searchbox').append("<div><form action='#' onsubmit='return false' id='search-form' method='post'><input id='searchfield' name='filter' size='10' class='ui-corner-all' value='Search...(wip)'><input type='hidden' name='objtype' value='detail' \><input type='hidden' name='objname' value='searchdb' \><input type='hidden' name='mincols' value='2' \><img id='searchsubmit' src='images/right.png' /></form></div>"); 
        break;
      case "host":  
        showMessage('Host Search')
        $('#searchbox').empty();
        $('#searchbox').append("<div><form action='#' onsubmit='return false' id='search-form' method='post'><input id='searchfield' name='filter' size='10' class='ui-corner-all' value='Search...(wip)'><input type='hidden' name='objtype' value='detail' \><input type='hidden' name='objname' value='searchhost' \><input type='hidden' name='mincols' value='2' \><img id='searchsubmit' src='images/right.png' /></form></div>");
        break;
      case "app":
        $('#searchbox').empty();
        $('#searchbox').append("<div><form action='#' onsubmit='return false' id='search-form' method='post'><input id='searchfield' name='filter' size='10' class='ui-corner-all' value='Search...(wip)'><input type='hidden' name='objtype' value='detail' \><input type='hidden' name='objname' value='searchapp' \><input type='hidden' name='mincols' value='2' \><img id='searchsubmit' src='images/right.png' /></form></div>"); 
        break;
      case "user":
        showMessage('User Search');
      default:
        //Report search
        $('#searchbox').empty();
        $('#searchbox').append("<div><form action='#' onsubmit='return false' id='search-form' method='post'><input id='searchfield' name='filter' size='10' class='ui-corner-all' value='Search...(wip)'><input type='hidden' name='objtype' value='gentable' \><input type='hidden' name='objname' value='searchreport' \><input type='hidden' name='mincols' value='2' \><img id='searchsubmit' src='images/right.png' /></form></div>");          
    }
    $('#search-form').submit(function(){$('#main-report').load('librarian.php', $('#search-form').serializeArray(),function(){$('.footable').footable();});});
    $('#searchfield').focus(function() { $(this).attr("value",""); });
    
  }
  
  function bindRes(){
    $('.resedit' ).click(function(){ editResource() }); 
    $('.resreset').click(function(){ resetResource() });
    $('#resresetbutton').hide();
    $('#reseditbutton').hide();
    if(loggedIn == true){$('.secure').show();}
    //$('.reseditsubmit').click(function(){ updateItem('host', filter); return false; });
  }
  
  function resetDialogs(){
    // Reset the dialogs
    $("#dialog-form").dialog({ 
      autoOpen: false, height: 430, width: 300, modal: false, stack: true,
      buttons: {  
        Close:  function() { $(this).dialog('close'); return false; },
        Update: function() { updateItem(); return false; } 
      }, 
      close: function(){ return false; } 
    });
    $("#dialog-small").dialog({ 
      autoOpen: false, height: 200, width: 200, modal: false, stack: true,
      buttons: {  
        OK:  function() { $(this).dialog('close'); return false; },
      }, 
      close: function(){ return false; } 
    });
    $("#dialog-form-login").dialog({ 
      autoOpen: false, height: 200, width: 200, modal: true, stack: true,
      buttons: {  
        Cancel: function() { $(this).dialog('close'); return false; },
        Login:  function() { runLogin(); return false; }
      }, 
      close: function(){ return false; } 
    });
    $("#dialog-form-wizard-next").dialog({ 
      autoOpen: false, height: 365, width: 300, modal: true, stack: true,
      buttons: {  
        Cancel: function() { $(this).dialog('close'); return false; },
        Next:  function() { wizardStep($('[name=step]').val()); return false; }
      }, 
      close: function(){ return false; } 
    });
  }
  
  function showMessage(message){
    //Display a simple pop-up
    $("#dialog-message-content").empty();
    $("#dialog-message-content").html("<div class='ui-widget'>" + message + "</div>" );
    $("#dialog-message").dialog({ 
      autoOpen: true, height: 200, width: 200, modal: true, stack: false, dialogClass: 'alert',
      buttons: {  
        OK: function() { $(this).dialog('close'); return false; }
      }, 
      close: function(){ return false; } 
    });
    
  }
  
  function add(type){
    //Handle adding new reports, dbs, hosts, etc
    switch (type){
      case "db":
        showMessage('WIP');
        break;
      case "host":  
        wizardStep('starthost');
        break;
      case "report":  
        showMessage('WIP');
        break;
      default:
        alert( "Unable to add items of type: " + type );        
    }
  }
  
  function wizardStep(step){
    // Attempt to make a much simpler and better written wizard
    switch(step) {
      case "starthost":
        // Used when creating a host by itself
        $('#dialog-form-wizard-content-next').load('librarian.php',{objtype:'wizard', step:'hoststart', mode:'hoststart'}, $('#currserver').focus()  );        
        break;
      case "pickserver":
        // Will display the picklist of existing servers
        $('#dialog-form-wizard-content-next').load('librarian.php', $('#update-form').serializeArray(), function(){$('#currserver').focus();});
        break;
      case "checkserver":
        // Will just make sure that the server name exists, or launch a create server with some checks
        newserver = $('[name=newserver]').val();
        curserver = $('[name=currserver]').val();
        serial = 'no serial';
        if($('[name=serial]').length){ serial = $('[name=serial]').val(); }
        if((curserver == 'new') && (newserver.length < 2)){ showMessage("Servername is too short. Try again."); }
        else if(serial.length < 2){ showMessage("Serial is too short. Try again"); }
        else{ $('#dialog-form-wizard-content-next').load('librarian.php', $('#update-form').serializeArray(), function(){$('#currserver').focus();}); }
        break;
      case "createhost":
        //Will display the host creation prompts
        //$('#dialog-form-wizard-content-next').load('librarian.php', $('#update-form').serializeArray(), function(){$('#currserver').focus();});
        showMessage ('WIP');
        break;
      default:
        showMessage( "Not sure what to do with " + step);
    }
    $('#dialog-form-wizard-next').dialog('open');
  }
  
  function editResource(filter) { 
    $('.res-view').hide();
    $('.res-edit').show(); 
    $('#reseditbutton').hide();
    $('#resresetbutton').show();  
    // Don't know why this form is trying to instantly submit, but this will stop it until then 
    $('#resource-form').submit(function(){ return false; });    
    return false;
  };
  
  function resetResource(filter) { 
    $('.res-view').show();
    $('.res-edit').hide(); 
    $('#reseditbutton').show();
    $('#resresetbutton').hide();         
    return false;
  };
});



//Great URL reader from http://jquery-howto.blogspot.com/2009/09/get-url-parameters-values-with-jquery.html
$.extend({
  getUrlVars: function(){
    var vars = [], hash;
    var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for(var i = 0; i < hashes.length; i++)
    {
      hash = hashes[i].split('=');
      vars.push(hash[0]);
      vars[hash[0]] = hash[1];
    }
    return vars;
  },
  getUrlVar: function(name){
    return $.getUrlVars()[name];
  }
});

