<?php //Commented due to conflict with php compression. if (substr_count($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip')) ob_start('ob_gzhandler'); else ob_start();
 // This is part of the Heron Enterprise Management Suite for OpenEngine.Org
 // This program is the web-based mid-tier for a server and db workflow management app
 // Version 0.1
 // All code and graphics © Copyright 2005-2013 Mike Bybee, OpenEngine.Org
 // All rights reserved.
 // This app is distributed under the BSD simplified license.
 // You may obtain a copy of the License at:
 // http://openengine.org/license.html 
 // Included libraries may be under LGPL or MIT licenses.
 // Libraries and Plugins Copyright their respective owners. See the libraries for their licenses.
?>

<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'
    'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>

 <head>
  <meta http-equiv='content-type' content='text/html; charset=iso-8859-1' />
  <title>Heron</title>
  <?php
   include_once 'js/scripts/jqFunc.php';
   insCSS();
  ?>
  <script type='text/javascript'> $(document).ready(function(){ $('.footable').footable(); });</script>
   
 </head>
 <body>
   <?php 
     //Only display reports for GET, everything else for POST
     if( isset($_GET['objtype']) ){
         $objtype = $_GET['objtype'];
         $objname = isset($_GET['objname']) ? $_GET['objname'] : 'hostshort';
         $filter  = isset($_GET['filter'])  ? $_GET['filter']  : '%';
         $order   = isset($_GET['order'])   ? $_GET['order']   : '';
         $mincols = isset($_GET['mincols']) ? $_GET['mincols'] : '1';    
         if( $objtype == 'gentable' ){ 
             print( "<div id='$objtype'>" );
             if( $objname == 'trueup'){ insTrueup(); }
             else{ insGenTable($objname, $filter, $order, 0, '', $mincols); }            
             print( "</div>" );
         }
     }
     if( isset($_POST['objtype']) ){
         $objtype = $_POST['objtype'];
         $objname = isset($_POST['objname']) ? $_POST['objname'] : 'hostshort';
         $limit   = isset($_POST['limit'])   ? $_POST['limit']   : 0;
         $filter  = isset($_POST['filter'])  ? $_POST['filter']  : '%';
         $order   = isset($_POST['order'])   ? $_POST['order']   : '';
         $level   = isset($_POST['level'])   ? $_POST['level']   : '';
         $step    = isset($_POST['step'])    ? $_POST['step']    : '';
         $type    = isset($_POST['type'])    ? $_POST['type']    : '';
         $edit    = isset($_POST['edit'])    ? $_POST['edit']    : '';
         $mincols = isset($_POST['mincols']) ? $_POST['mincols'] : '1';
         
         if( $objtype == 'related'){ insObjects($objtype, $objname, $limit, $filter, $order); }
         elseif( $objtype == 'gentable' ){
             // print( "Got stuff: $objtype, $objname, $limit, $filter, $order" ); 
             // Set some reports non-editable due to various reasons
             if( strpos($objname, 'cmdb') > -1 ){$edit = '';}
             if( $objname == 'syslong'         ){$edit = '';}
             if( $objname == 'network'         ){$edit = '';}
             if( $objname == 'datacenter'      ){$edit = '';}
             if( $objname == 'trueup'          ){$edit = '';}
             if( $objname == 'instances'       ){$edit = '';}
             
             print( "<div id='$objtype'>" );
             if( $objname == 'trueup'){ insTrueup(); }
             else{ insGenTable($objname, $filter, $order, $limit, $edit, $mincols); }            
             print( "</div>" );
         }
         elseif( $objtype == 'wizard'){ itemWizard($step, $_POST); } 
         elseif( $objtype == 'detail' ){ print "<div id='$objtype'>" . insDetail($objname, $filter, $level) . "</div>\n"; } 
         elseif( $objtype == 'upditem'){ print "<div id='form'>" . updItem($type, $objname, $_POST) . "</div>"; }
         else{ print( "<div id='$objtype'>" . insObjects($objtype, $objname, $limit, $filter, $order) . "</div>\n" ); }	   	 
     }
     elseif( isset($_POST['login']) ){
         print( "<div id='form'>" );
             $loginid = $_POST['login'];
             $hash    = crypt($_POST['hash']);            
             print( "Got stuff: $loginid, $hash" );
             login('form', $loginid, $hash);
     }
     else{
         print("Nothing to see here");
         print_r($_GET);
         print( "<p>" );
         print_r($_POST);
         print("</p>");
     }    
   ?>
 </body>
</html>
